Create ChatGPT pet row `jumping` for `broomstep`: exactly 5 full-body frames in one horizontal strip on flat pure blue #0000FF.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: Broomstep is a tiny wooden hut on two sturdy chicken legs, wearing a roof painted like a kerchief. Its crooked wooden body has warm cream window eyes, a narrow door and a little broom secured beside it. Broad rust and ochre roof shapes form a simple ornamental border; a few fixed ink marks suggest boards and feathers.

It is curious, sly and kind to the brave. It approaches unfamiliar things with one lifted claw and a forward lean, then pauses as though deciding whether to offer shelter or play a small trick. Confidence stretches its legs; disappointment folds them; delight makes the whole house perk upward. Its magic has a stubborn streak: the broom starts work by itself, sometimes before the hut has finished looking around. One window briefly narrows in a wink while the broom sweeps close behind its feet, suggesting erased tracks without drawing footprints.

Keep the hut small, earthy and clearly wooden. The chicken legs, kerchief roof and attached door broom remain its defining features through every pose. Use sincere eyes, matte paint and slightly uneven ink edges. Give waiting an outward lean, work an active broom sweep and review an inward inspection of the still broom. All expression belongs to the creature and its existing belongings; the surrounding cell stays empty.
Use a squat ochre wooden body, rust kerchief roof with cream border shapes, soot ink edges and herb green door accents. Two cream windows hold clear, sincere dark eyes. Thick chicken shanks end in widely spaced claws. The small broom stays secured at the door and pivots within reach of the feet. Keep board marks sparse, roof patterns fixed and the leg gap open through turns.
Do not resemble: No franchise look-alike, logo, real-person likeness or copied artwork. The name is John Wick's nickname in the film series, and a hut that walks on legs echoes Howl's Moving Castle. Keep the folk hut, legs and broom, but give it a display name of our own and draw its legs and roof pattern in our style, not a walking castle's.
Readability notes from the image jury: make waiting, focused work (running row 7), and review read differently from idle and from each other at 192 × 208. Apply the winning style's supplied attributed drawing notes to this pet, including the reference pet. Carry them into every image prompt. These are drawing guidance; keep the fixed family reference and the v2 contract.
Painter/Enchanted-workshop guidance: distinctly outward waiting, low active broom sweep for work, raised still broom and inward bristle inspection for review. Snow-queen guidance: distinguish neighboring upward direction steps using body pitch and whole window-eye gaze.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Hover jump loop: anticipation, lift, airborne peak, descent, and settle through body height.

State requirements:
- Show the jump through pose and vertical body position only: anticipation, lift, airborne peak, descent, settle.
- Do not draw ground shadows, contact shadows, drop shadows, oval shadows, landing marks, dust, smears, bounce pads, or motion marks under the pet.
- Keep the background outside the pet perfectly flat chroma key with no darker key-colored patches.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #0000FF colors in the pet.
