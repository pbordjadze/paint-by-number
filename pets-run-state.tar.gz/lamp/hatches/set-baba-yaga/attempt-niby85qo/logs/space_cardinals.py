import sys,json
from PIL import Image
sys.path.insert(0,'/root/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/create-pet/scripts')
from extract_strip_frames import component_frame_groups,component_group_image,component_bounds
im=Image.open('decoded/look-cardinals.png').convert('RGBA');groups=component_frame_groups(im,4);assert groups is not None
ims=[component_group_image(im,g) for g in groups]; w=max(x.width for x in ims)+80;h=max(x.height for x in ims)+80
out=Image.new('RGBA',(4*w,h))
for i,x in enumerate(ims):out.alpha_composite(x,(i*w+(w-x.width)//2,h-40-x.height))
out.save('decoded/look-cardinals-spaced.png')
p=json.load(open('logs/provenance.json'));p['repairs'].append('cardinal extraction repair 1 (deterministic): source-slot edges contained 25–27 stray alpha pixels; used bundled connected-component grouping to repack four complete unscaled poses with padding, then reran the bundled cardinal extractor.');json.dump(p,open('logs/provenance.json','w'),indent=2)
