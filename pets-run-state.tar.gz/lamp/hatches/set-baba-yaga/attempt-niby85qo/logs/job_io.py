import sys,json,pathlib,re,shutil,datetime
P=pathlib.Path.cwd();mode=sys.argv[1];jid=sys.argv[2];jobs=json.loads((P/'imagegen-jobs.json').read_text());j=next(j for j in jobs['jobs'] if j['id']==jid)
if mode=='prepare':
    prompt=(P/j['prompt_file']).read_text()
    prompt=prompt.replace('on a perfectly flat pure blue #0000FF chroma-key background','on a genuinely transparent background').replace('on flat pure blue #0000FF','on genuine transparency').replace('Keep the background outside the pet perfectly flat chroma key with no darker key-colored patches.','Keep the background outside the pet genuinely transparent.')
    prompt+='\nReference roles: the complete ram family sheet is STYLE ONLY, not the subject. Draw only Broomstep the wooden chicken-legged hut. Canonical hut image defines identity. Layout guide defines spacing only, never render guide marks.\n'
    if jid.startswith('look-'):
        prompt+='\nFULL BINDING STYLE TASTE:\n'+(P/'logs/taste.txt').read_text()+'\nFULL PET NOTES AND AVOIDANCES:\n'+(P/'logs/pet-notes.txt').read_text()
    req=json.loads((P/'logs/request.json').read_text())
    if jid in req['brief']['rows']:prompt+='\nSpecific row choreography: '+req['brief']['rows'][jid]+'\n'+req['style']['rows'][jid]+'\nUse only the required frame count above; four beats are remapped to it. Eight fps is rhythm guidance.\n'
    prompt+='\nOutput actual transparent RGBA art; no labels or checkerboard. Keep all poses distinct and separated in one horizontal row. No extra props.\n'
    if (P/'logs'/f'{jid}-extra.txt').exists():prompt+='\n'+(P/'logs'/f'{jid}-extra.txt').read_text()
    refs=[str(P/i['path']) for i in j['input_images']]
    args=dict(prompt=prompt,referenced_image_paths=refs,transparent_background=True)
    prov=json.loads((P/'logs/provenance.json').read_text());prov['image_generations']+=1;n=prov['image_generations'];(P/'logs/provenance.json').write_text(json.dumps(prov,indent=2))
    (P/'logs'/f'generation-{n:02d}-{jid}.json').write_text(json.dumps(dict(job=jid,count=n,args=args,output_path=j['output_path']),indent=2));print(json.dumps(args))
elif mode=='save':
    src=pathlib.Path(sys.argv[3]);dst=P/j['output_path'];shutil.copy2(src,dst)
    with (P/'logs/generated-sources.jsonl').open('a') as f:f.write(json.dumps(dict(job=jid,cache_path=str(src),local_path=str(dst)))+'\n')
    j['status']='generated';(P/'imagegen-jobs.json').write_text(json.dumps(jobs,indent=2));print(str(dst))
