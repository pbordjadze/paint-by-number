from pathlib import Path
import json,hashlib
P=Path.cwd(); p=json.load(open('logs/provenance.json'))
p['decisions']=[d for d in p['decisions'] if not d.startswith('Encode final WebP with quality') and not d.startswith('Supersede quality-88')]
p['decisions'] += [
'Final encoding uses a 256-entry RGBA palette, no dithering, lossless WebP method 6, and explicit zero RGB at zero alpha. RGB-only quantization remained over 2 MB; RGBA quantization produces a 697746-byte atlas with genuine transparent surroundings. The final contact sheet is 577670 bytes.',
'Bundled default preview timings preserve held poses: idle 280/110/110/140/140/320 ms; directional runs 120 ms with 220 ms final; waving/jumping 140 ms with 280 ms final; failed 140 ms with 240 ms final; waiting 150 ms with 260 ms final; work 120 ms with 220 ms final; review 150 ms with 280 ms final. Eight fps was rhythm guidance, not a fixed final playback requirement.',
'Motion target versus observation: jump target 10–14 px, observed 35 px airborne lift with 1 px landing delta. It still expresses crouch, spring, airborne peak and landing; no repair was spent on amplitude. Idle breath target 1–2 px, observed silhouette top range 7–18 and bottom range 199–201, including blink/posture changes; it remains a calm planted blink/breath cycle.',
'Framing guidance target settled base y=184 and safe region x=16–176,y=16–192; bundled shared component fitting yielded idle median baseline y=201, with work x=14–178 and jump peak top y=6. All exact v2 cells passed structural checks; these drawing-guidance differences were recorded rather than separately gated.',
'Three isolated read-only reviewers completed the bundled blind axis procedure. All cardinal axes passed; horizontal axes of 022.5 and 045 drew majority disagreement and are retained as labeled-review warnings because upper-right pupil cues remain visible against a near-neutral facade.',
'Continuity alpha-hole warnings correspond to intentional open leg and claw gaps, not missing wood or facial material. The automated quality gate passes with 11.5 px maximum horizontal center drift and 1.239 maximum silhouette width ratio.',
'Independent final review found blocking visible scale pops at row 9 frame 7 to row 10 frame 0 and row 10 frame 7 to row 9 frame 0. Row 10 is consistently smaller. This is a visible continuity failure, not rejection for missing a style motion target.',
'Stop as failed after the two allowed row-10 repairs. Preserve final/spritesheet.webp, all authentic QA reports and GIF/MP4 previews as a local unaccepted candidate; no further row repair or whole-pet redo is authorized.',
'All previews were rendered from the exact final WebP. Nine per-state GIFs use the bundled renderer; all-state, idle-jump-idle and look-loop GIFs use its save_preview function, with MP4 copies encoded by ffmpeg. Contact sheet and four labeled motion stills were visually inspected.'
]
p['repairs'][-1]='Final encoding repair: lossy WebP introduced hidden RGB beneath zero alpha; RGB-only palette encoding remained too large. Final 256-entry RGBA quantization plus lossless WebP and zeroed hidden RGB passes structural validation within budget. No second despill.'
p['status']='failed';p['reason']='Independent final visual review found scale pops at the look-row boundaries after row 10 exhausted both allowed repairs. Automated atlas, quality and blind-cardinal validators pass; candidate is not accepted.'
(P/'logs/provenance.json').write_text(json.dumps(p,indent=2))
sem=json.load(open('qa/direction-semantics.json'));sem['continuity_notes']='Open leg and claw gaps explain alpha-hole warnings. Independent final visual review fails the row-boundary scale pops at 157.5→180 and 337.5→000; see qa/final-visual-review.json. Direction classifications remain as observed, but the candidate is not accepted.';(P/'qa/direction-semantics.json').write_text(json.dumps(sem,indent=2))
# Record archived sources faithfully rather than leaving superseded paths pointing at replacements.
records=[json.loads(x) for x in (P/'logs/generated-sources.jsonl').read_text().splitlines()];seen={}
for r in records:
 j=r['job'];seen[j]=seen.get(j,0)+1
 if j in ['running-left','running'] and seen[j]==1:r['local_path']=str(P/'decoded'/f'{j}-attempt-1.png')
 if j=='look-row-10' and seen[j]<3:r['local_path']=str(P/'decoded'/f'{j}-attempt-{seen[j]}.png')
 r['sha256']=hashlib.sha256(Path(r['local_path']).read_bytes()).hexdigest()
(P/'logs/generated-sources.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records))
assert len(records)==p['image_generations']==17
metadata={'name':'Broomstep','description':json.load(open('logs/request.json'))['brief']['description'],'status':p['status'],'sprite_version_number':2,'atlas':'final/spritesheet.webp','atlas_sha256':hashlib.sha256((P/'final/spritesheet.webp').read_bytes()).hexdigest(),'encoded_bytes':(P/'final/spritesheet.webp').stat().st_size,'image_generations':17,'reason':p['reason'],'qa':['qa/chroma-despill-extended.json','qa/review.json','qa/direction-semantics.json','qa/look-continuity.json','qa/pet-quality.json','qa/final-visual-review.json']}
(P/'final/metadata.json').write_text(json.dumps(metadata,indent=2))
reply={k:p[k] for k in ['status','reason','image_generations','repairs','contract_overrides','decisions']};(P/'logs/final-reply.json').write_text(json.dumps(reply,indent=2))
print(json.dumps({'status':p['status'],'image_generations':p['image_generations'],'bundle_bytes':sum((P/x).stat().st_size for x in ['final/spritesheet.webp','previews/contact-sheet.webp','final/metadata.json']),'overrides':len(p['contract_overrides']),'repairs':len(p['repairs'])},indent=2))
