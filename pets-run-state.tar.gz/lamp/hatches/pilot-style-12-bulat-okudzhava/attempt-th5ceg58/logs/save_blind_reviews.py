import json,pathlib
base=[('horizontal-1','screen-right','screen-left'),('horizontal-2','screen-right','screen-left'),('horizontal-3','screen-right','screen-left'),('horizontal-4','screen-right','screen-left'),('horizontal-5','screen-right','screen-left'),('horizontal-6','screen-left','screen-right'),('horizontal-7','screen-left','screen-right'),('vertical-1','up','down'),('vertical-2','down','up'),('vertical-3','down','up'),('vertical-4','up','down'),('vertical-5','down','up'),('vertical-6','up','down'),('vertical-7','down','up')]
reasons={
'a':[
"A's pupils favor the right sides of the eye whites. B's pupils are high and nearly centered, leaving lateral direction unclear.",
"A's pupils sit toward the right eye edges; B's favor the left edges.",
"A leaves more white to the left of its pupils, while B leaves more white to their right.",
"The pupils visibly favor the right portions in A and the left portions in B.",
"A's low pupils sit at the right sides of the eyes; B's low pupils sit at the left sides.",
"A's pupils occupy the lower-left eye areas, while B's occupy the lower-right areas.",
"Along the bottom eye edges, A's pupils favor the left and B's favor the right.",
"A's pupils sit high with substantial white below; B's pupils sit against the lower eye edges.",
"A leaves white above its low pupils; B leaves white beneath its high pupils.",
"A's pupils occupy the lower eye portions, while B's occupy the upper portions.",
"A's pupils sit modestly above the eye centers with white beneath; B's sit lower with white above.",
"A's pupils touch the bottom portions of the eyes; B's pupils sit near the tops.",
"A has white beneath its high pupils; B has white above its low pupils.",
"A's pupils favor the bottom eye edges, while B's favor the upper eye areas."],
'b':[
"A's pupils sit toward the right sides of the eye whites; B's pupils sit toward the left sides.",
"A shows more eye white left of the pupils; B shows more white to their right.",
"A's dark pupils are displaced rightward within the whites; B's are displaced leftward.",
"A's pupils favor the right edges of the whites; B's favor the left edges.",
"The lowered pupils sit toward the right in A and toward the left in B.",
"A's low pupils are left-shifted; B's low pupils are right-shifted.",
"A's pupils occupy the lower-left eye areas; B's occupy the lower-right eye areas.",
"A's pupils sit high in the whites with white beneath them; B's sit near the lower edges.",
"A's pupils are close to the bottom eyelids; B's pupils are elevated within the whites.",
"A leaves more white above the pupils; B leaves more white below them.",
"A's pupils sit higher within the whites; B's sit toward the lower edges. The vertical difference is relatively subtle.",
"A's pupils cluster near the bottom of the eye whites; B's cluster near their tops.",
"A shows high pupils with visible white beneath; B shows low pupils with visible white above.",
"A's pupils occupy the lower eye areas; B's pupils occupy the upper eye areas."],
'c':[
"A's pupils favor the right sides of the eye whites; B's pupils favor the left sides.",
"A has more visible white to the left of its pupils; B has more visible white to their right.",
"A's pupils are displaced toward the right edges of the eye openings; B's are displaced toward the left edges.",
"A's pupils appear rightward within the whites; B's appear leftward. The displacement is subtle.",
"A's low-set pupils favor the right sides of the eyes; B's favor the left sides.",
"A's pupils sit toward the lower-left portions of the whites; B's sit toward the lower-right portions.",
"A's pupils crowd the left portions of the low eye openings; B's crowd the right portions.",
"A's pupils sit high with white below; B's sit near the lower eyelids with white above.",
"A's pupils sit at the bottom of the eye whites; B's sit toward the upper portions.",
"A has visibly lowered pupils and white above them; B has elevated pupils and white beneath them.",
"Both sets of pupils appear around the middle-to-lower portions of their eye openings. Neither provides a confident upward versus downward reading.",
"A's pupils sit against the lower eye edges; B's sit near the upper edges with substantial white below.",
"A's pupils sit high in the tall eye whites; B's sit low beneath visible white.",
"A's pupils are lowered toward the bottom eyelids; B's are elevated with white underneath."]}
for who,rr in reasons.items():
 records=[dict(pair=p,A=a,B=b,reason=r) for (p,a,b),r in zip(base,rr)]
 if who=='a':records[0]['B']='ambiguous'
 if who=='c':records[10]['A']=records[10]['B']='ambiguous'
 pathlib.Path(f'qa/blind-reviewer-{who}.json').write_text(json.dumps({'reviewer':'/root/blind_reviewer_'+who,'sheet':'previews/blind-directions-final.png','pairs':records},indent=2))
