import json,pathlib,sys,shutil,subprocess
root=pathlib.Path.cwd(); skill=pathlib.Path('/root/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/create-pet/scripts'); action=sys.argv[1]; name=sys.argv[2]
mp=root/'imagegen-jobs.json'; m=json.loads(mp.read_text());j=next(j for j in m['jobs'] if j['id']==name)
if action=='start':
 p=root/'logs/provenance.json';d=json.loads(p.read_text());d['image_generations']+=1;p.write_text(json.dumps(d,indent=2,ensure_ascii=False));refs=[str(root/i['path']) for i in j['input_images']];prompt=(root/j['prompt_file']).read_text()
 with open(root/'logs/generations.jsonl','a') as f:f.write(json.dumps(dict(index=d['image_generations'],job=name,prompt_file=j['prompt_file'],references=j['input_images'],redo=False))+'\n')
 print(json.dumps(dict(prompt=prompt,referenced_image_paths=refs,transparent_background=True)))
elif action=='save':
 source=pathlib.Path(sys.argv[3]); target=root/j['output_path'];shutil.copy2(source,target)
 with open(root/'logs/sources.jsonl','a') as f:f.write(json.dumps(dict(job=name,cache_path=str(source),local_path=str(target)))+'\n')
 if name=='base':shutil.copy2(target,root/'references/canonical-base.png')
 print(str(target))
elif action=='check':
 out=root/'qa/rows'/name/'frames'
 for script,args in [('extract_strip_frames.py',['--decoded-dir',str(root/'decoded'),'--output-dir',str(out),'--states',name,'--method','components']),('inspect_frames.py',['--frames-root',str(out),'--json-out',str(root/'qa/rows'/name/'review.json'),'--states',name,'--require-components'])]:
  r=subprocess.run(['python3',str(skill/script)]+args,capture_output=True,text=True);(root/'logs'/f'{name}-{script}.log').write_text(r.stdout+r.stderr);print(r.stdout[-2000:],r.stderr[-1000:]);
  if r.returncode:sys.exit(r.returncode)
elif action=='approve':
 j['status']='complete';mp.write_text(json.dumps(m,indent=2));print('approved '+name)
