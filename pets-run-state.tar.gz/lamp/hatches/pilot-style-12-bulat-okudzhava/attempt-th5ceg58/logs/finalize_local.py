import pathlib,json,shutil,hashlib
root=pathlib.Path.cwd();provpath=root/'logs/provenance.json';prov=json.loads(provpath.read_text());records=[json.loads(l) for l in (root/'logs/generations.jsonl').read_text().splitlines()];sources=[json.loads(l) for l in (root/'logs/sources.jsonl').read_text().splitlines()]
source_dir=root/'sources';source_dir.mkdir(exist_ok=True);prompt_dir=root/'logs/generation-prompts';prompt_dir.mkdir(exist_ok=True)
original_indices={2:'idle',7:'jumping',10:'waiting',12:'running'};repair_indices={3,8,11,13};seen={}
for rec,src in zip(records,sources):
 index=rec['index'];job=rec['job'];target=source_dir/f'{index:02d}-{job}.png';shutil.copy2(src['cache_path'],target)
 prompt_path=root/(rec.get('prompt_file') or rec['prompt'])
 if index in original_indices:prompt_path=root/f'logs/{original_indices[index]}-original-prompt.md'
 snapshot=prompt_dir/f'{index:02d}-{job}.md';shutil.copy2(prompt_path,snapshot)
 rec.update(prompt_file=str(snapshot.relative_to(root)),source_cache_path=src['cache_path'],source_local_path=str(target.relative_to(root)),source_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),internal_repair=index in repair_indices,jury_redo=False,transparent_background=True)
 rec['attempt']=seen.get(job,0)+1;seen[job]=rec['attempt'];rec['redo']=index in repair_indices
 for ref in rec['references']:
  path=root/ref['path'];ref['sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
(root/'logs/generation-audit.json').write_text(json.dumps({'tool':'built-in imagegen','image_generations':len(records),'jobs':records},indent=2))
(root/'logs/generations.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in records))
# Preserve every technical choice, explicitly distinguish superseded export experiments.
prov['decisions']=[x.replace('Use quality-90 WebP for final packaging because lossless exceeded the total 2 MB envelope; rerun validators and render all final previews from these exact bytes.','A quality-90 export was tested for size, then rejected because it introduced hidden RGB under zero alpha; the final uses lossless encoding after RGB palette reduction.') for x in prov['decisions']]
prov['decisions'] += ['Use three isolated read-only visual reviewers as required by the bundled blind-review stage; generation remains single-owner and sequential.','Retain reviewed warnings for subtle intermediate gaze steps and wheel-gap continuity flags; all cardinal votes and the combined blind-axis gate pass.','Generate every final contact sheet, nine state GIFs, combined GIF/MP4, idle-jump-idle GIF/MP4, ordered-look GIF/MP4 and labeled motion stills from the exact final WebP.','Archive all 17 original cache sources under sources/ and immutable prompt snapshots under logs/generation-prompts/; four calls were internal single-row repairs, with no jury redo.']
provpath.write_text(json.dumps(prov,indent=2,ensure_ascii=False))
m=json.loads((root/'imagegen-jobs.json').read_text())
for job in m['jobs']:job['status']='complete'
(root/'imagegen-jobs.json').write_text(json.dumps(m,indent=2))
sem=json.loads((root/'qa/direction-semantics.json').read_text());sem['blind_review']='Three isolated reviewers; qa/blind-validation.json passes by strict majority. Some intermediate axes retain individual ambiguity warnings.';(root/'qa/direction-semantics.json').write_text(json.dumps(sem,indent=2))
metadata={'key':'pilot-style-12-bulat-okudzhava','pet':'bulat-okudzhava','local_only':True,'spriteVersionNumber':2,'atlas':'final/spritesheet.webp','dimensions':[1536,2288],'cell':[192,208],'reference':None,'request':json.loads((root/'logs/request.json').read_text()),'provenance':prov,'sha256':hashlib.sha256((root/'final/spritesheet.webp').read_bytes()).hexdigest(),'previews':'previews/','reports':['qa/chroma-despill-extended.json','qa/review.json','qa/direction-semantics.json','qa/look-continuity.json','qa/pet-quality.json','qa/blind-validation.json']}
(root/'final/metadata.json').write_text(json.dumps(metadata,indent=2,ensure_ascii=False))
size=sum((root/p).stat().st_size for p in ['final/spritesheet.webp','previews/contact-sheet.webp','final/metadata.json'])
(root/'logs/package-size.json').write_text(json.dumps({'atlas_bytes':(root/'final/spritesheet.webp').stat().st_size,'compressed_contact_bytes':(root/'previews/contact-sheet.webp').stat().st_size,'metadata_bytes':(root/'final/metadata.json').stat().st_size,'combined_bytes':size,'limit_bytes':2000000},indent=2))
result={'status':'complete','reason':f'Local final/spritesheet.webp is 1536×2288 and passes bundled atlas, pet-quality and blind-direction validation. Required reports and motion previews are saved locally. Atlas + compressed contact + metadata: {size} bytes. No service or Library calls.','image_generations':prov['image_generations'],'repairs':prov['repairs'],'contract_overrides':prov['contract_overrides'],'decisions':prov['decisions']}
(root/'logs/result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False));print(json.dumps({'status':result['status'],'image_generations':result['image_generations'],'package_bytes':size,'sha256':metadata['sha256']},indent=2))
