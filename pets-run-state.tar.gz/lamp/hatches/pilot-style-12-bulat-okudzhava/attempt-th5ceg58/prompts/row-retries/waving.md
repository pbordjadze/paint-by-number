Create ChatGPT pet row `waving` for `bulat-okudzhava`: exactly 4 full-body frames in one horizontal strip on genuinely transparent alpha.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A little blue trolleybus with warm lit windows, rolling slowly down a night street, a guitar resting on one seat. No background street. Use a compact blue trolleybus with sincere eyes painted on its front windshield, two attached roof trolley poles, soot wheels, cream windows, and an ochre/rust guitar securely visible on a seat; no human likeness. Avoid: No franchise look-alike, logo, real-person likeness or copied artwork.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Greeting loop: paw or limb down, raised, tilted, and returning in a friendly attention gesture.

State requirements:
- Show the greeting through paw, hand, wing, or limb pose only.
- Do not draw wave marks, motion arcs, lines, sparkles, symbols, or floating effects around the gesture.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.

REQUIRED BEAT REMAP: 1 viewer-facing; 2 tilt up in greeting; 3 clear greeting tilt; 4 settle.
Beat 1: turn toward the viewer. Beat 2: raise an available limb, cover, branch or body edge. Beat 3: make one clear greeting sweep. Beat 4: lower and settle. Bodies without limbs tilt in greeting. Keep held flames and jars upright. Play once.
True alpha transparency, never draw checkerboard. No labels. All poses same scale. Art only, no human portraits. Output wide landscape strip when multiple poses are requested.