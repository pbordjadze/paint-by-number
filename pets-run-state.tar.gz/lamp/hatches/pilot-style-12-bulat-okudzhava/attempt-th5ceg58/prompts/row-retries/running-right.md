Create ChatGPT pet row `running-right` for `bulat-okudzhava`: exactly 8 full-body frames in one horizontal strip on genuinely transparent alpha.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A little blue trolleybus with warm lit windows, rolling slowly down a night street, a guitar resting on one seat. No background street. Use a compact blue trolleybus with sincere eyes painted on its front windshield, two attached roof trolley poles, soot wheels, cream windows, and an ochre/rust guitar securely visible on a seat; no human likeness. Avoid: No franchise look-alike, logo, real-person likeness or copied artwork.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Dragging-right loop: show directional movement to the right through body and limb poses only.

State requirements:
- Show directional drag movement to the right through body, limb, and prop movement only.
- The row must unmistakably face and travel right.
- The movement cadence must alternate visibly across the 8 frames instead of repeating one nearly static stride.
- Do not draw speed lines, dust clouds, floor shadows, motion trails, or detached motion effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.

REQUIRED BEAT REMAP: 1–2 first wheel contact; 3–4 lift/pass with wheel rotation; 5–6 opposite contact; 7–8 return.
Face right. Beat 1: first contact. Beat 2: lift and pass. Beat 3: opposite contact. Beat 4: lift and return. Legs stride, wheels turn, covers or bee wings beat; legless bodies tip and bob along the same pulse. Keep carried objects secure.
True alpha transparency, never draw checkerboard. No labels. All poses same scale. Art only, no human portraits. Output wide landscape strip when multiple poses are requested.