Create ChatGPT pet row `idle` for `bulat-okudzhava`: exactly 6 full-body frames in one horizontal strip on genuinely transparent alpha.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A little blue trolleybus with warm lit windows, rolling slowly down a night street, a guitar resting on one seat. No background street. Use a compact blue trolleybus with sincere eyes painted on its front windshield, two attached roof trolley poles, soot wheels, cream windows, and an ochre/rust guitar securely visible on a seat; no human likeness. Avoid: No franchise look-alike, logo, real-person likeness or copied artwork.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Calm low-distraction resting loop: subtle breathing, tiny blink, slight head/body bob, and only quiet persona-preserving motion.

State requirements:
- CRITICAL: idle is the low-distraction baseline state and the first frame is also used as the reduced-motion static pet.
- Use only subtle idle motion: gentle breathing, a tiny blink, a slight head or body bob, a very small material sway, or another quiet motion that fits the pet persona.
- Keep the pet essentially in the same pose, facing direction, silhouette, markings, palette, and prop state across all 6 frames.
- Idle variation must stay calm but still read as animation; do not repeat effectively identical copies across the loop.
- Do not show waving, walking, running, jumping, talking, working, reviewing, emotional reactions, large gestures, item interactions, or new props.
- Feet, base, body, or object anchor should remain planted or nearly planted.
- The first and last frames should be very close visually so the loop feels calm and does not pop.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.

REQUIRED BEAT REMAP: 1 settled; 2–3 slow blink; 4–5 breathe 1–2 px; 6 return and hold.
Beat 1: settled pose. Beat 2: one slow blink or slight head dip. Beat 3: a 1–2 pixel breath. Beat 4: return and hold. Keep sleepy pets curled, proud pets upright and the palette quietly seated. Loop gently.
True alpha transparency, never draw checkerboard. No labels. All poses same scale. Art only, no human portraits. Output wide landscape strip when multiple poses are requested.