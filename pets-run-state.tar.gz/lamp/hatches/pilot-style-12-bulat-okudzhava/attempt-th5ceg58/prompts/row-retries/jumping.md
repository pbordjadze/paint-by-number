Create ChatGPT pet row `jumping` for `bulat-okudzhava`: exactly 5 full-body frames in one horizontal strip on genuinely transparent alpha.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A little blue trolleybus with warm lit windows, rolling slowly down a night street, a guitar resting on one seat. No background street. Use a compact blue trolleybus with sincere eyes painted on its front windshield, two attached roof trolley poles, soot wheels, cream windows, and an ochre/rust guitar securely visible on a seat; no human likeness. Avoid: No franchise look-alike, logo, real-person likeness or copied artwork.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Hover jump loop: anticipation, lift, airborne peak, descent, and settle through body height.

State requirements:
- Show the jump through pose and vertical body position only: anticipation, lift, airborne peak, descent, settle.
- Do not draw ground shadows, contact shadows, drop shadows, oval shadows, landing marks, dust, smears, bounce pads, or motion marks under the pet.
- Keep the background outside the pet fully transparent.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.

REQUIRED BEAT REMAP: 1 suspension compresses; 2 rise; 3 peak 14 px above baseline; 4 descend; 5 land and settle.
Beat 1: crouch or compress. Beat 2: rise 10–14 pixels. Beat 3: reach the peak and descend. Beat 4: land, soften and settle. Winged pets use a brief upward flap; the trolleybus gives a small springy hop. Show no trails or landing marks. Play once.
True alpha transparency, never draw checkerboard. No labels. All poses same scale. Art only, no human portraits. Output wide landscape strip when multiple poses are requested.