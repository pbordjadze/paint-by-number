import json,pathlib,sys,shutil,datetime
r=pathlib.Path.cwd(); jobs=json.loads((r/'imagegen-jobs.json').read_text()); job=next(j for j in jobs['jobs'] if j['id']==sys.argv[2]);p=r/'logs/provenance.json'; prov=json.loads(p.read_text())
if sys.argv[1]=='start':
 refs=[str(r/x['path']) for x in job['input_images']]; prompt=(r/job['prompt_file']).read_text()
 n=prov['image_generations']+1;prov['image_generations']=n;p.write_text(json.dumps(prov,indent=2,ensure_ascii=False))
 entry=dict(number=n,job=job['id'],prompt=prompt,inputs=job['input_images'],references=refs,started=datetime.datetime.now(datetime.timezone.utc).isoformat(),redo=False)
 (r/f'logs/generation-{n:02d}.json').write_text(json.dumps(entry,indent=2,ensure_ascii=False))
 args=dict(prompt=prompt,transparent_background=True)
 if refs:args['referenced_image_paths']=refs
 print(json.dumps(args))
elif sys.argv[1]=='save':
 source=pathlib.Path(sys.argv[3]);dst=r/job['output_path'];dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dst)
 n=prov['image_generations'];entryp=r/f'logs/generation-{n:02d}.json';entry=json.loads(entryp.read_text());entry.update(cache_source=str(source),copied_source=str(dst));entryp.write_text(json.dumps(entry,indent=2,ensure_ascii=False))
 if job['id']=='base':shutil.copy2(dst,r/'references/canonical-base.png')
 print(dst)
elif sys.argv[1]=='approve':
 job['status']='complete';(r/'imagegen-jobs.json').write_text(json.dumps(jobs,indent=2));print(job['id']+' approved')
