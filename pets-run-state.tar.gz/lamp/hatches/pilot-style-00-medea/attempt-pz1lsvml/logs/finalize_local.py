from pathlib import Path
from PIL import Image
import json,hashlib
root=Path.cwd();sources=[]
for p in sorted((root/'logs').glob('generation-[0-9][0-9].json')):
 v=json.loads(p.read_text());source=Path(v['copied_source']);v['source_sha256']=hashlib.sha256(source.read_bytes()).hexdigest();p.write_text(json.dumps(v,indent=2,ensure_ascii=False));sources.append({k:v[k] for k in ['number','job','attempt','cache_source','copied_source','source_sha256']})
(root/'logs/generated-sources.json').write_text(json.dumps(sources,indent=2))
Image.open('previews/contact-sheet.png').convert('RGB').save('previews/contact-sheet.webp',quality=82,method=6)
p=root/'logs/provenance.json';v=json.loads(p.read_text());v['decisions'][12]='Trial encoding used quality 92/method 6 after the bundled lossless WebP exceeded the combined delivery budget; the trial failed hidden-RGB validation and was superseded.';v['decisions'][14]='Second encoding trial used 256-color RGB quantization with original alpha and lossless WebP; it passed validation but remained too large with contact/metadata and was superseded.'
v['decisions'].extend(['Read-only isolated blind axis review used three reviewers per bundled skill instructions; all 28 axis classifications passed unanimously after row-10 repair.', 'Continuity warnings were visually inspected: hoof gaps and space between horns are intentional exterior negative space; the 157.5-to-180 difference reflects head yaw into a frontal downward pose. Similar upper diagonals remain documented warnings.', 'All final previews and qa/review.json were regenerated from the exact final WebP. Required reports are authentic bundled outputs except the explicitly requested visual direction semantic observations.'])
v.update(status='complete',reason='Local v2 candidate saved as final/spritesheet.webp; exact WebP passes bundled atlas and pet-quality validation, and all blind direction checks pass. Required reports and GIF/MP4 previews are saved locally. No service or Library calls occurred.')
p.write_text(json.dumps(v,indent=2,ensure_ascii=False));(root/'logs/final-result.json').write_text(json.dumps(v,indent=2,ensure_ascii=False))
meta={'key':'pilot-style-00-medea','pet':'medea','atlas':'final/spritesheet.webp','sha256':hashlib.sha256((root/'final/spritesheet.webp').read_bytes()).hexdigest(),'width':1536,'height':2288,'sprite_version':2,'image_generations':v['image_generations'],'jury_redos':0,'contract_overrides':v['contract_overrides'],'decisions':v['decisions'],'repairs':v['repairs'],'generated_sources':sources}
(root/'final/metadata.json').write_text(json.dumps(meta,ensure_ascii=False,separators=(',',':')))
paths=['final/spritesheet.webp','previews/contact-sheet.webp','final/metadata.json'];sizes={x:(root/x).stat().st_size for x in paths};sizes['total_bytes']=sum(sizes.values());(root/'qa/delivery-size.json').write_text(json.dumps(sizes,indent=2));print(json.dumps(sizes,indent=2));print('generations',v['image_generations'])
m=root/'imagegen-jobs.json';jobs=json.loads(m.read_text());next(j for j in jobs['jobs'] if j['id']=='look-row-10')['status']='complete';m.write_text(json.dumps(jobs,indent=2))
