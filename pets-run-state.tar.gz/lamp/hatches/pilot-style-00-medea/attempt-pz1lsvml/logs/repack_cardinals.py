import sys,json
from pathlib import Path
from PIL import Image
sys.path.insert(0,'/root/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/create-pet/scripts')
from extract_strip_frames import component_frame_groups,component_bounds,component_group_image
im=Image.open('decoded/look-cardinals.png').convert('RGBA');groups=component_frame_groups(im,4)
assert groups and len(groups)==4
boxes=[component_bounds(g) for g in groups];w=max(b[2]-b[0] for b in boxes)+120;h=im.height+40
out=Image.new('RGBA',(w*4,h))
for i,g in enumerate(groups):
 part=component_group_image(im,g);out.alpha_composite(part,(i*w+(w-part.width)//2,boxes[i][1]+16))
out.save('decoded/look-cardinals-padded.png')
p=Path('logs/provenance.json');v=json.loads(p.read_text());v['repairs'].append('Deterministic cardinal extraction repair: bundled fixed source slots intersected low-alpha background residue. Recovered complete pose groups using bundled component grouping, repacked them with transparent padding without changing their pixels/scale, then reran the cardinal script.');p.write_text(json.dumps(v,indent=2,ensure_ascii=False))
