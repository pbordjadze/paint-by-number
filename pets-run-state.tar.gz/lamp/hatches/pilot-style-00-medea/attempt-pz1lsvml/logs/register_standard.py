from pathlib import Path
from PIL import Image
import json
root=Path.cwd(); entries=[]
for d in (root/'frames-raw').iterdir():
 if not d.is_dir():continue
 files=sorted(d.glob('*.png'));ims=[Image.open(p).convert('RGBA') for p in files]
 # Whole-row transforms preserve every pose's relative scale and airborne displacement.
 scale=.84 if d.name=='jumping' else .78
 size=(round(192*scale),round(208*scale));res=[im.resize(size,Image.Resampling.LANCZOS) for im in ims]
 baseline=max(im.getbbox()[3] for im in res); offset=((192-size[0])//2,184-baseline)
 dest=root/'frames'/d.name;dest.mkdir(parents=True,exist_ok=True)
 for p,im in zip(files,res):
  canvas=Image.new('RGBA',(192,208));canvas.alpha_composite(im,offset);canvas.save(dest/p.name)
 entries.append(dict(state=d.name,shared_scale=scale,offset=offset,baseline=184))
(root/'logs/standard-registration.json').write_text(json.dumps(entries,indent=2))
p=root/'logs/provenance.json';v=json.loads(p.read_text());v['repairs'].append('Deterministic registration after bundled component extraction: shared 0.78 scale for standard rows and 0.84 for the jump viewport, translated to y=184 baseline; preserve within-row pose sizes and jump displacement, enforce 16 px safe margins.');v['decisions'].append('The generated base is in its happy leafy state. Review explicitly closes and unfolds an attached terminal bud while retaining the existing back twig and leaves.');p.write_text(json.dumps(v,indent=2,ensure_ascii=False))
