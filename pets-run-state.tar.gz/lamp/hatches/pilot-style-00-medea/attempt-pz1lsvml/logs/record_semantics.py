import json,pathlib
labels=['000','022.5','045','067.5','090','112.5','135','157.5','180','202.5','225','247.5','270','292.5','315','337.5']
expected=['up','up-right','up-right','up-right','right','down-right','down-right','down-right','down','down-left','down-left','down-left','left','up-left','up-left','up-left']
evidence=[
'Chin exposed, nose pitched toward top edge and both original pupils raised; torso planted.',
'Raised muzzle and pupils show upward pitch; muzzle shifts slightly screen-right relative to frontal head.',
'Nose extends screen-right; chin raised and pupil near upper eye rim.',
'Right-projecting muzzle with upward eye and head pitch; close to 045 but remains upper-right.',
'Profile nose projects screen-right and face aims horizontally right; feet and herbs retain anchored placement.',
'Right-facing muzzle tips below eye line toward herbs; pupils/head aim down-right.',
'Crown leans forward with muzzle low and screen-right; eyes follow lower-right.',
'Muzzle lowered strongly with subtle retained right yaw; both eyes face below-right toward herbs.',
'Frontal bowed head, centered low muzzle, eyes directed toward hooves; horns remain above face.',
'Bowed head and low nose offset screen-left; eyes follow down-left, maintaining lower half.',
'Nose projects left beneath eye level and head pitches down; visible eye looks lower-left.',
'Left-projecting muzzle held slightly lower, with eyes lowered; left component dominates the down-left pose.',
'Head profile and nose point screen-left; torso/twig/herb-holding limb stay fixed.',
'Left-projecting muzzle lifted above its horizontal cardinal position; chin and pupil aim upper-left.',
'Raised left muzzle and upward eye placement show upper-left; similar to 292.5 but no quadrant reversal.',
'Near-frontal head pitches upward, with slight left yaw/nose bias and eyes raised toward upper-left; joins up anchor.'
]
records=[dict(label=l,expected=e,observed=e,verdict='warning' if l in ['045','067.5','292.5','315'] else 'pass',evidence=ev) for l,e,ev in zip(labels,expected,evidence)]
pathlib.Path('qa/direction-semantics.json').write_text(json.dumps({'ok':True,'atlas':'final/spritesheet.webp','reviewer':'primary labeled native-size visual review','directions':records,'continuity_review':{'alpha_hole_warnings':'Rows near y=174–176 are intentional negative space between separate hooves; 180 y=46 is between horns above the crown, not an interior body seam.','boundary_157_5_to_180':'Larger silhouette difference corresponds to head moving from oblique down-right into frontal down; planted torso, herbs and hooves remain coherent. No direction reversal or scale snap observed.','warnings':'Some upper diagonals have similar pitch; retain as semantic warnings rather than distinct-angle precision claims.'}},indent=2))
