Create one horizontal look-direction strip for ChatGPT pet `medea`, atlas row 9.

Use the attached canonical base, completed standard contact sheet, layout guide, and approved four-cardinal strip for identity, scale, registration, spacing, direction semantics, and cross-row continuity. Read `qa/look-mechanics.md` and follow its pet-specific movement and eye/prop mechanics. The approved cardinal strip is authoritative for the up, screen-right, down, and screen-left pose families. Interpolate the intermediate directions as even 22.5-degree steps between those anchors.

COHERENT SYNTHESIS LOCK: produce one unified eight-pose row. Do not paste, tile, or independently restyle individual cells. Every final cell must be drawn together with the same face construction, body proportions, line/render quality, lighting, materials, scale, baseline, and registration.

Output exactly 8 complete full-body frames in this exact left-to-right order: 000, 022.5, 045, 067.5, 090, 112.5, 135, 157.5. Degrees are clockwise: 000 is up, 090 right, 180 down, and 270 left. Neutral/front is not part of this row.

DIRECTION TARGETS — use these to shape the coherent row, not as pixel-level landmark gates:

1. `000`: vertical UP; no horizontal requirement.
2. `022.5`: horizontal SCREEN-RIGHT and vertical UP.
3. `045`: horizontal SCREEN-RIGHT and vertical UP.
4. `067.5`: horizontal SCREEN-RIGHT and vertical UP.
5. `090`: horizontal SCREEN-RIGHT; no vertical requirement.
6. `112.5`: horizontal SCREEN-RIGHT and vertical DOWN.
7. `135`: horizontal SCREEN-RIGHT and vertical DOWN.
8. `157.5`: horizontal SCREEN-RIGHT and vertical DOWN.

Cardinals must be unmistakable. Intermediate poses should broadly occupy the intended quadrant and advance naturally through the ordered loop. Minor pupil, nose, eyelid, or aiming-feature deviations are acceptable when the overall direction, continuity, identity, and motion remain coherent. Do not deform the character merely to make every intermediate axis independently obvious.

SCREEN-COORDINATE LOCK: screen-right means the viewer's right image edge, never the character's own right. The row should travel naturally through the right half of the loop. Near-vertical 022.5 and 157.5 may have subtle horizontal cues; prioritize a coherent arc over exact pupil or nose placement.

HARD LAYOUT AND CONTINUITY CONTRACT — DETERMINISTIC REGISTRATION: draw exactly eight separated pose groups in left-to-right direction order. Keep enough fully transparent space between neighboring poses that each complete pose can be detected without cutting through foreground. Approximate the guide's equal spacing, but do not distort a pose merely to hit an exact source-canvas coordinate; deterministic assembly will crop the eight ordered groups, then apply one shared scale and baseline.

Use the same body height, head size, baseline, and planted-body position across the generated family. Never overlap neighboring poses, merge two poses into one connected group, crop foreground at the outer canvas edge, or resize one pose independently.

Keep the feet, base, or lower torso planted at the same coordinates across all eight frames. Express direction through the eyes, face, head, upper body, and physically appropriate prop movement, not by moving, rotating, or rescaling the entire sprite.

Place one centered pose in each invisible equal-width slot on genuine alpha transparency. Change only the natural parts needed to express gaze: eyes, eyelids, head, face, neck, upper body, appendages, and constrained prop follow-through. Keep identity, silhouette, materials, palette, markings, and props consistent.

ROW-BOUNDARY LOCK: 157.5 must be one even 22.5-degree step before 180. Match the approved 180 pose's body size, baseline, planted anchor, expression, and construction. Preserve the overall right-hand arc, but do not distort pupils, nose, or body geometry merely to exaggerate the subtle horizontal component.

PRE-RETURN CHECK: reject this result if it does not contain eight separated pose groups in the required order; neighboring poses overlap; foreground is cropped at the outer canvas edge; any frame changes sprite scale, body or head size, baseline, or planted-body position; the row visibly reverses into the wrong half of the loop; or 157.5 does not flow evenly into 180. Minor intermediate pupil or nose deviations are not rejection reasons. Exact cell cropping, resizing, and recentering happen deterministically after generation.

Do not rotate, skew, or tilt the whole sprite to fake gaze. Do not add replacement/googly eyes, labels, degree text, arrows, clocks, grids, shadows, glows, scenery, detached effects, or chroma-key colors inside the pet.

Pet identity and constraints: A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.
Do not resemble: No franchise look-alike, logo, real-person likeness or copied artwork.
Only this ram appears. It carries herbs in a forehoof near its chest; a dry twig is physically attached to the upper back. Kind, confident, caring temperament.
Full style taste (painterly): Twenty distinct companions share a steady hand, clear shapes and small acts of care. Warm gold and herb green meet deep ink within each pet, leaving the background clear. Beauty comes from useful movement: a twig greens, a brush tends its jar, a book changes its drawings. Keep confidence, kindness and each seed’s own temperament. Glass stays clear; ink stays handmade. Their shared shape, scale and timing make them family.
Transparent 192 × 208 cells, fixed camera and scale. Keep every moving part inside a 16 px safe margin. Fit the tallest or widest pose first; never shrink individual frames. Standing pets share a baseline at y=184; flying and gliding creatures keep a stable resting center. Leave room above for jumps. No scene or ground plane. The giraffe’s black-ground character becomes dark body markings and flat warm paint, without a background rectangle.
Base: deep ink #252732, old gold #BD9148, herb green #66794A, cream #EFE4CA. Preserve identifying colors, clear glass and the ermine’s cool white. Accents occupy existing surfaces; they never add objects. Surface treatments respect seed materials: wood remains wood, fleece remains fleece, glass remains transparent.
Use gently uneven 3 px outer ink lines and 2 px essential inner lines at native size. Keep eyes, eyebrow, feet and carried objects separate; omit fine detail that collapses. One existing pattern per patterned seed, simplified into broad shapes. Resolve ink versus glass through a material exception: the droplet and magnifying lens use transparent centers, soft colored rims and two broad highlights, with no hard ink around the clear material. Ink may outline the magnifying handle and eyebrow. Glass receives no paper grain; ink pets receive no glass coating. Shared proportions, palette accents and timing provide unity.
Preserve all twenty seeds and their temperaments. Magnifying glass: skeptical raised eyebrow and deliberate checking. Golden ram: kind eyes, old-gold fleece, carried herbs and attached twig whose leaves visibly unfold. Hut: wooden walls, chicken legs, kerchief roof and original broom; sweep without rendered footprints. Mushroom: sleepy mossy cap, tarragon feather and herb basket. Crescent: existing warm lantern, quiet light held inside its shape. Ermine: elegant white body and frost crown; show frost through attached pale facets, without a trail. Reindeer calf: loyal mischief, embroidered felt blanket and firm hoof stamp. Book: flapping covers and changing wordless ink pictures. Brush: determined face, tiny legs and existing paint jar. Inkpot: thoughtful nod, round spectacles and tucked quill; underline through motion without leaving marks. Palette: warm paint dabs, brush tail and modest posture. Lamb: striped nightcap, original candle and curled rest; suggest humming through gentle breathing. Droplet: calm clear body and bounded inner warmth. Giraffe: sincere eyes, flat warm paint and its own markings. Bee: white collar, pressed flower and one brief tracing gesture without written text. Pomegranate: cheerful opening to share attached visible seeds; no airborne seeds. Nutcracker: wooden soldier, original back key and courteous salute. Tuning fork: precise turns and poised tips; ringing conveyed by a brief body vibration. Blue trolleybus: slow wheels, warm windows and guitar visible on its existing seat; no street. Clay lamp: kind contained flame and grapevine around its handle. Add no family-wide herbs, keys, lights, costumes or other props. No floating effects, particles, text, speech bubbles, shadows or scene backgrounds in any row, including review. All pets and assets remain local.
Look mechanics: feet and torso stay planted; head and neck bend/yaw/pitch naturally, original eyes look with the head, horns and ears follow the head. Nose and eyes unmistakably show screen-coordinate direction. Keep fleece, herb sprig and attached twig identical.

Output art has genuine transparency, no labels, no guide marks, no shadows. Keep a single consistent old-gold/cream fleece, deep ink line, herb-green leaf palette. Use generously separated complete poses.

ANCHORED RAM LOCK: in every pose, keep the canonical torso in the identical front three-quarter orientation with tail and back twig at screen-left, herbs held at screen-right chest, and hooves fixed. Only neck, head, original eyes, ears and horns turn/pitch; no body turntable and no swapped props. Match approved cardinal head pitch and yaw. All frames have open eyes so gaze is visible.
