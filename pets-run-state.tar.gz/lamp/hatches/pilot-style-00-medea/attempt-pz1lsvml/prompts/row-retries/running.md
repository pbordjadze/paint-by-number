Create ChatGPT pet row `running` for `medea`: exactly 6 full-body frames in one horizontal strip on genuine alpha transparency.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.
Do not resemble: No franchise look-alike, logo, real-person likeness or copied artwork.
Only this ram appears. It carries herbs in a forehoof near its chest; a dry twig is physically attached to the upper back. Kind, confident, caring temperament.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Working loop: focused active-task processing, thinking, typing, scanning, or effortful concentration; not literal foot-running, jogging, sprinting, treadmill motion, raised knees, long steps, pumping arms, or directional travel.

State requirements:
- Show the pet actively working or processing, as if running a task: focused posture, busy hands or paws, purposeful bobbing, thinking motion, tool or prop motion only if already part of the pet identity, or other non-locomotion activity.
- Do not show literal foot-running, jogging, sprinting, treadmill motion, raised knees, long steps, pumping arms, directional travel, speed lines, dust clouds, floor shadows, motion trails, or detached motion effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.

Authoritative action/timing remap: 6 frames of focused work without locomotion: 1 prepare, 2–3 gently stir/move the carried herbs without a new vessel, 4 inspect as attached bud opens, 5–6 reset. Loop; 120 ms each, final 220 ms.

Output art has genuine transparency, no labels, no guide marks, no shadows. Keep a single consistent old-gold/cream fleece, deep ink line, herb-green leaf palette. Use generously separated complete poses.
