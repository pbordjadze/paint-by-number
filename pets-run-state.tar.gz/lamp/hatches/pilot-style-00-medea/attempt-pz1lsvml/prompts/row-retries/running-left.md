Create ChatGPT pet row `running-left` for `medea`: exactly 8 full-body frames in one horizontal strip on genuine alpha transparency.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.
Do not resemble: No franchise look-alike, logo, real-person likeness or copied artwork.
Only this ram appears. It carries herbs in a forehoof near its chest; a dry twig is physically attached to the upper back. Kind, confident, caring temperament.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Dragging-left loop: show directional movement to the left through body and limb poses only.

State requirements:
- Show directional drag movement to the left through body, limb, and prop movement only.
- The row must unmistakably face and travel left.
- The movement cadence must alternate visibly across the 8 frames instead of repeating one nearly static stride.
- Do not draw speed lines, dust clouds, floor shadows, motion trails, or detached motion effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.

Authoritative action/timing remap: 8 frames facing screen-left: two four-frame gait cycles, frames 1–4 and 5–8; contacts on 1 and 5. Redraw asymmetric herbs and attached twig in anatomically consistent locations. Bundled timing: 120 ms each, final 220 ms.

Output art has genuine transparency, no labels, no guide marks, no shadows. Keep a single consistent old-gold/cream fleece, deep ink line, herb-green leaf palette. Use generously separated complete poses.
