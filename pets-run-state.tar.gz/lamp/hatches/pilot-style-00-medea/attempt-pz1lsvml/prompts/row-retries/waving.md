Create ChatGPT pet row `waving` for `medea`: exactly 4 full-body frames in one horizontal strip on genuine alpha transparency.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.
Do not resemble: No franchise look-alike, logo, real-person likeness or copied artwork.
Only this ram appears. It carries herbs in a forehoof near its chest; a dry twig is physically attached to the upper back. Kind, confident, caring temperament.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Greeting loop: paw or limb down, raised, tilted, and returning in a friendly attention gesture.

State requirements:
- Show the greeting through paw, hand, wing, or limb pose only.
- Do not draw wave marks, motion arcs, lines, sparkles, symbols, or floating effects around the gesture.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.

Authoritative action/timing remap: 4 frames: 1 prepare, 2 lift forehoof, 3 greet, 4 return. Play once; 140 ms each, final 280 ms.

Output art has genuine transparency, no labels, no guide marks, no shadows. Keep a single consistent old-gold/cream fleece, deep ink line, herb-green leaf palette. Use generously separated complete poses.
