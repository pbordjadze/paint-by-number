Create ChatGPT pet row `idle` for `medea`: exactly 6 full-body frames in one horizontal strip on genuine alpha transparency.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.
Do not resemble: No franchise look-alike, logo, real-person likeness or copied artwork.
Only this ram appears. It carries herbs in a forehoof near its chest; a dry twig is physically attached to the upper back. Kind, confident, caring temperament.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Calm low-distraction resting loop: subtle breathing, tiny blink, slight head/body bob, and only quiet persona-preserving motion.

State requirements:
- CRITICAL: idle is the low-distraction baseline state and the first frame is also used as the reduced-motion static pet.
- Use only subtle idle motion: gentle breathing, a tiny blink, a slight head or body bob, a very small material sway, or another quiet motion that fits the pet persona.
- Keep the pet essentially in the same pose, facing direction, silhouette, markings, palette, and prop state across all 6 frames.
- Idle variation must stay calm but still read as animation; do not repeat effectively identical copies across the loop.
- Do not show waving, walking, running, jumping, talking, working, reviewing, emotional reactions, large gestures, item interactions, or new props.
- Feet, base, body, or object anchor should remain planted or nearly planted.
- The first and last frames should be very close visually so the loop feels calm and does not pop.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.

Authoritative action/timing remap: 6 frames: 1–2 breathe, 3–4 blink, 5–6 settle into frame 1. Use bundled per-frame durations 280,110,110,140,140,320 ms instead of the shared 12 fps/24-frame clock.

Output art has genuine transparency, no labels, no guide marks, no shadows. Keep a single consistent old-gold/cream fleece, deep ink line, herb-green leaf palette. Use generously separated complete poses.
