Create one horizontal look-direction strip for ChatGPT pet `medea`, atlas row 9.

Use the attached canonical base, completed standard contact sheet, layout guide, and approved four-cardinal strip for identity, scale, registration, spacing, direction semantics, and cross-row continuity. Read `qa/look-mechanics.md` and follow its pet-specific movement and eye/prop mechanics. The approved cardinal strip is authoritative for the up, screen-right, down, and screen-left pose families. Interpolate the intermediate directions as even 22.5-degree steps between those anchors.

COHERENT SYNTHESIS LOCK: produce one unified eight-pose row. Do not paste, tile, or independently restyle individual cells. Every final cell must be drawn together with the same face construction, body proportions, line/render quality, lighting, materials, scale, baseline, and registration.

Output exactly 8 complete full-body frames in this exact left-to-right order: 000, 022.5, 045, 067.5, 090, 112.5, 135, 157.5. Degrees are clockwise: 000 is up, 090 right, 180 down, and 270 left. Neutral/front is not part of this row.

DIRECTION TARGETS — use these to shape the coherent row, not as pixel-level landmark gates:

1. `000`: vertical UP; no horizontal requirement.
2. `022.5`: horizontal SCREEN-RIGHT and vertical UP.
3. `045`: horizontal SCREEN-RIGHT and vertical UP.
4. `067.5`: horizontal SCREEN-RIGHT and vertical UP.
5. `090`: horizontal SCREEN-RIGHT; no vertical requirement.
6. `112.5`: horizontal SCREEN-RIGHT and vertical DOWN.
7. `135`: horizontal SCREEN-RIGHT and vertical DOWN.
8. `157.5`: horizontal SCREEN-RIGHT and vertical DOWN.

Cardinals must be unmistakable. Intermediate poses should broadly occupy the intended quadrant and advance naturally through the ordered loop. Minor pupil, nose, eyelid, or aiming-feature deviations are acceptable when the overall direction, continuity, identity, and motion remain coherent. Do not deform the character merely to make every intermediate axis independently obvious.

SCREEN-COORDINATE LOCK: screen-right means the viewer's right image edge, never the character's own right. The row should travel naturally through the right half of the loop. Near-vertical 022.5 and 157.5 may have subtle horizontal cues; prioritize a coherent arc over exact pupil or nose placement.

HARD LAYOUT AND CONTINUITY CONTRACT — DETERMINISTIC REGISTRATION: draw exactly eight separated pose groups in left-to-right direction order. Keep enough chroma-only space between neighboring poses that each complete pose can be detected without cutting through foreground. Approximate the guide's equal spacing, but do not distort a pose merely to hit an exact source-canvas coordinate; deterministic assembly will crop the eight ordered groups, then apply one shared scale and baseline.

Use the same body height, head size, baseline, and planted-body position across the generated family. Never overlap neighboring poses, merge two poses into one connected group, crop foreground at the outer canvas edge, or resize one pose independently.

Keep the feet, base, or lower torso planted at the same coordinates across all eight frames. Express direction through the eyes, face, head, upper body, and physically appropriate prop movement, not by moving, rotating, or rescaling the entire sprite.

Place one centered pose in each invisible equal-width slot on flat pure magenta #FF00FF. Change only the natural parts needed to express gaze: eyes, eyelids, head, face, neck, upper body, appendages, and constrained prop follow-through. Keep identity, silhouette, materials, palette, markings, and props consistent.

ROW-BOUNDARY LOCK: 157.5 must be one even 22.5-degree step before 180. Match the approved 180 pose's body size, baseline, planted anchor, expression, and construction. Preserve the overall right-hand arc, but do not distort pupils, nose, or body geometry merely to exaggerate the subtle horizontal component.

PRE-RETURN CHECK: reject this result if it does not contain eight separated pose groups in the required order; neighboring poses overlap; foreground is cropped at the outer canvas edge; any frame changes sprite scale, body or head size, baseline, or planted-body position; the row visibly reverses into the wrong half of the loop; or 157.5 does not flow evenly into 180. Minor intermediate pupil or nose deviations are not rejection reasons. Exact cell cropping, resizing, and recentering happen deterministically after generation.

Do not rotate, skew, or tilt the whole sprite to fake gaze. Do not add replacement/googly eyes, labels, degree text, arrows, clocks, grids, shadows, glows, scenery, detached effects, or chroma-key colors inside the pet.


## Binding full user style and pet notes
{
  "name": "Medea — The Kind Turning",
  "preset": "painterly",
  "style_notes": "Twenty distinct companions share a steady hand, clear shapes and small acts of care. Warm gold and herb green meet deep ink within each pet, leaving the background clear. Beauty comes from useful movement: a twig greens, a brush tends its jar, a book changes its drawings. Keep confidence, kindness and each seed’s own temperament. Glass stays clear; ink stays handmade. Their shared shape, scale and timing make them family.",
  "framing": "Transparent 192 × 208 cells, fixed camera and scale. Keep every moving part inside a 16 px safe margin. Fit the tallest or widest pose first; never shrink individual frames. Standing pets share a baseline at y=184; flying and gliding creatures keep a stable resting center. Leave room above for jumps. No scene or ground plane. The giraffe’s black-ground character becomes dark body markings and flat warm paint, without a background rectangle.",
  "palette": "Base: deep ink #252732, old gold #BD9148, herb green #66794A, cream #EFE4CA. Preserve identifying colors, clear glass and the ermine’s cool white. Accents occupy existing surfaces; they never add objects. V2 adds sixteen looks to the base, each available across all twenty pets and all nine rows: 1. Moon Herb—silver cream, deep green, sparse gold; 2. Old Gold—ochre midtones, brown ink, green accents; 3. Fresh Leaf—light green accents, pale cream, dark ink; 4. Tarragon—gray green, straw gold, dry brush edges; 5. Moss—deep olive accents and broad soft stippling; 6. Parchment—warm cream, sepia lines, muted green; 7. Night Ink—larger dark areas, cream features, small gold accents; 8. Clay Hearth—terracotta accents, warm cream, olive; 9. Pomegranate—seed red accents, cream, dark green; 10. Blue Window—muted blue, amber highlights, soft gray; 11. Frost Linen—cool white, slate, pale gold; 12. Brass Grain—brass accents with three broad grain marks; 13. Soft Felt—matte color with short broken edge strokes; 14. Dry Brush—visible broad brush ends and flat color; 15. Fine Ink—cleaner sparse lines and broad quiet fills; 16. Clear Morning—lighter fills and wider clear areas in glass only. Surface treatments respect seed materials: wood remains wood, fleece remains fleece, glass remains transparent. Looks are distinct through large color areas and visible stroke choices, not tiny decoration.",
  "line": "Use gently uneven 3 px outer ink lines and 2 px essential inner lines at native size. Keep eyes, eyebrow, feet and carried objects separate; omit fine detail that collapses. One existing pattern per patterned seed, simplified into broad shapes. Resolve ink versus glass through a material exception: the droplet and magnifying lens use transparent centers, soft colored rims and two broad highlights, with no hard ink around the clear material. Ink may outline the magnifying handle and eyebrow. Glass receives no paper grain; ink pets receive no glass coating. Shared proportions, palette accents and timing provide unity.",
  "boundaries": "Preserve all twenty seeds and their temperaments. Magnifying glass: skeptical raised eyebrow and deliberate checking. Golden ram: kind eyes, old-gold fleece, carried herbs and attached twig whose leaves visibly unfold. Hut: wooden walls, chicken legs, kerchief roof and original broom; sweep without rendered footprints. Mushroom: sleepy mossy cap, tarragon feather and herb basket. Crescent: existing warm lantern, quiet light held inside its shape. Ermine: elegant white body and frost crown; show frost through attached pale facets, without a trail. Reindeer calf: loyal mischief, embroidered felt blanket and firm hoof stamp. Book: flapping covers and changing wordless ink pictures. Brush: determined face, tiny legs and existing paint jar. Inkpot: thoughtful nod, round spectacles and tucked quill; underline through motion without leaving marks. Palette: warm paint dabs, brush tail and modest posture. Lamb: striped nightcap, original candle and curled rest; suggest humming through gentle breathing. Droplet: calm clear body and bounded inner warmth. Giraffe: sincere eyes, flat warm paint and its own markings. Bee: white collar, pressed flower and one brief tracing gesture without written text. Pomegranate: cheerful opening to share attached visible seeds; no airborne seeds. Nutcracker: wooden soldier, original back key and courteous salute. Tuning fork: precise turns and poised tips; ringing conveyed by a brief body vibration. Blue trolleybus: slow wheels, warm windows and guitar visible on its existing seat; no street. Clay lamp: kind contained flame and grapevine around its handle. Add no family-wide herbs, keys, lights, costumes or other props. No floating effects, particles, text, speech bubbles, shadows or scene backgrounds in any row, including review. All pets and assets remain local.",
  "rows": {
    "idle": "Shared clock for every row: 12 fps, 24 frames, four half-second beats. Idle: settled front three-quarter pose; frames 1–6 breathe, 7–12 blink, 13–24 settle. Smallest motion; loop seamlessly.",
    "running-right": "Face and travel right in place. Two clear gait cycles, frames 1–12 and 13–24; contact or strongest wing stroke on 1 and 13. Lean right. Use legs, wheels, covers, wings or body glide as the seed allows.",
    "running-left": "Same clock and gait facing left, with a clear left lean. Redraw asymmetric carried objects and markings so they stay on their proper side; do not blindly mirror the sheet.",
    "waving": "Face the viewer. Frames 1–6 prepare, 7–12 lift a limb, cover, tip or existing held object, 13–18 make one greeting, 19–24 return. The soldier salutes. Play once.",
    "jumping": "Frames 1–6 compress, 7–12 rise, 13–18 reach the apex and descend, 19–24 land and recover. Flying pets make one upward lift. Clear vertical displacement distinguishes this from running. Play once.",
    "failed": "Frames 1–6 stop, 7–12 lower the head or leading edge, 13–18 hold a small inward pose, 19–24 recover to a steady low stance. No injury, destruction, extinguished life or withering. Play once, then hold.",
    "waiting": "Upright and expectant, gaze turned outward. Frames 1–6 look aside, 7–12 make one small weight shift, 13–24 hold. Loop quietly. Keep the open posture distinct from idle’s relaxed rest and review’s inward attention.",
    "running": "Task in progress, facing front three-quarter without directional travel. Frames 1–6 prepare, 7–12 work, 13–18 inspect, 19–24 reset. Use each seed’s own action: stir with the ram’s herbs, sweep, tend the jar, turn a page, open the fruit or make a measured fork turn. A tiny attached bud opens on the ram’s beat-three check. Loop smoothly.",
    "review": "Stop locomotion and inspect closely. Frames 1–6 lean inward, 7–12 examine an existing object or body detail, 13–18 give one restrained nod, 19–24 hold the result. On the ram, the attached bud unfolds into leaves during frames 13–18: the renewal has a visible moment. No new props, marks or effects. Play once and hold."
  },
  "why": "The family shows care through deliberate work and visible renewal, while each seed keeps its own creature, material and personality. Paul’s approval steps are waived for this run; his later veto remains. No veto is issued here. Originality may veto only in a jury and never ranks taste. Any later veto must quote the exact applicable guards-against charter line and give a concrete reason. The Painter’s function review must inspect the base and sixteen added looks at native size across all nine rows. Record defects as evidence-based flags naming the pet, look, row and frame: for example, a lens rim disappearing, herbs merging with fleece, clipping, or waiting and review sharing an indistinguishable pose. These are review criteria, not claims that sheets have already passed."
}

{
  "seed": "A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.",
  "do_not_resemble": [
    "No franchise look-alike, logo, real-person likeness or copied artwork."
  ]
}

Background requirement: genuine transparency; no labels, guide marks, shadows or background. The family reference is currently missing; DO NOT SUBMIT this job until its input is resolved.
