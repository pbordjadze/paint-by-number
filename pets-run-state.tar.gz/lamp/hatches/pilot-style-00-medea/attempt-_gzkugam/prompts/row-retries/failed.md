Create ChatGPT pet row `failed` for `medea`: exactly 8 full-body frames in one horizontal strip on flat pure magenta #FF00FF.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: {
  "seed": "A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.",
  "do_not_resemble": [
    "No franchise look-alike, logo, real-person likeness or copied artwork."
  ]
}. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Blocked/failed loop: slumped or deflated reaction with sad or closed eyes.

State requirements:
- Show failure through slumped pose, drooping ears/limbs, closed or sad eyes, and lower body position.
- Tears, small smoke puffs, or tiny stars are allowed only if attached to or overlapping the pet silhouette and kept inside the same frame slot.
- Do not draw red X marks, floating symbols, detached stars, separated smoke clouds, falling tear drops, dust, or other loose effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.


## Binding full user style and pet notes
{
  "name": "Medea — The Kind Turning",
  "preset": "painterly",
  "style_notes": "Twenty distinct companions share a steady hand, clear shapes and small acts of care. Warm gold and herb green meet deep ink within each pet, leaving the background clear. Beauty comes from useful movement: a twig greens, a brush tends its jar, a book changes its drawings. Keep confidence, kindness and each seed’s own temperament. Glass stays clear; ink stays handmade. Their shared shape, scale and timing make them family.",
  "framing": "Transparent 192 × 208 cells, fixed camera and scale. Keep every moving part inside a 16 px safe margin. Fit the tallest or widest pose first; never shrink individual frames. Standing pets share a baseline at y=184; flying and gliding creatures keep a stable resting center. Leave room above for jumps. No scene or ground plane. The giraffe’s black-ground character becomes dark body markings and flat warm paint, without a background rectangle.",
  "palette": "Base: deep ink #252732, old gold #BD9148, herb green #66794A, cream #EFE4CA. Preserve identifying colors, clear glass and the ermine’s cool white. Accents occupy existing surfaces; they never add objects. V2 adds sixteen looks to the base, each available across all twenty pets and all nine rows: 1. Moon Herb—silver cream, deep green, sparse gold; 2. Old Gold—ochre midtones, brown ink, green accents; 3. Fresh Leaf—light green accents, pale cream, dark ink; 4. Tarragon—gray green, straw gold, dry brush edges; 5. Moss—deep olive accents and broad soft stippling; 6. Parchment—warm cream, sepia lines, muted green; 7. Night Ink—larger dark areas, cream features, small gold accents; 8. Clay Hearth—terracotta accents, warm cream, olive; 9. Pomegranate—seed red accents, cream, dark green; 10. Blue Window—muted blue, amber highlights, soft gray; 11. Frost Linen—cool white, slate, pale gold; 12. Brass Grain—brass accents with three broad grain marks; 13. Soft Felt—matte color with short broken edge strokes; 14. Dry Brush—visible broad brush ends and flat color; 15. Fine Ink—cleaner sparse lines and broad quiet fills; 16. Clear Morning—lighter fills and wider clear areas in glass only. Surface treatments respect seed materials: wood remains wood, fleece remains fleece, glass remains transparent. Looks are distinct through large color areas and visible stroke choices, not tiny decoration.",
  "line": "Use gently uneven 3 px outer ink lines and 2 px essential inner lines at native size. Keep eyes, eyebrow, feet and carried objects separate; omit fine detail that collapses. One existing pattern per patterned seed, simplified into broad shapes. Resolve ink versus glass through a material exception: the droplet and magnifying lens use transparent centers, soft colored rims and two broad highlights, with no hard ink around the clear material. Ink may outline the magnifying handle and eyebrow. Glass receives no paper grain; ink pets receive no glass coating. Shared proportions, palette accents and timing provide unity.",
  "boundaries": "Preserve all twenty seeds and their temperaments. Magnifying glass: skeptical raised eyebrow and deliberate checking. Golden ram: kind eyes, old-gold fleece, carried herbs and attached twig whose leaves visibly unfold. Hut: wooden walls, chicken legs, kerchief roof and original broom; sweep without rendered footprints. Mushroom: sleepy mossy cap, tarragon feather and herb basket. Crescent: existing warm lantern, quiet light held inside its shape. Ermine: elegant white body and frost crown; show frost through attached pale facets, without a trail. Reindeer calf: loyal mischief, embroidered felt blanket and firm hoof stamp. Book: flapping covers and changing wordless ink pictures. Brush: determined face, tiny legs and existing paint jar. Inkpot: thoughtful nod, round spectacles and tucked quill; underline through motion without leaving marks. Palette: warm paint dabs, brush tail and modest posture. Lamb: striped nightcap, original candle and curled rest; suggest humming through gentle breathing. Droplet: calm clear body and bounded inner warmth. Giraffe: sincere eyes, flat warm paint and its own markings. Bee: white collar, pressed flower and one brief tracing gesture without written text. Pomegranate: cheerful opening to share attached visible seeds; no airborne seeds. Nutcracker: wooden soldier, original back key and courteous salute. Tuning fork: precise turns and poised tips; ringing conveyed by a brief body vibration. Blue trolleybus: slow wheels, warm windows and guitar visible on its existing seat; no street. Clay lamp: kind contained flame and grapevine around its handle. Add no family-wide herbs, keys, lights, costumes or other props. No floating effects, particles, text, speech bubbles, shadows or scene backgrounds in any row, including review. All pets and assets remain local.",
  "rows": {
    "idle": "Shared clock for every row: 12 fps, 24 frames, four half-second beats. Idle: settled front three-quarter pose; frames 1–6 breathe, 7–12 blink, 13–24 settle. Smallest motion; loop seamlessly.",
    "running-right": "Face and travel right in place. Two clear gait cycles, frames 1–12 and 13–24; contact or strongest wing stroke on 1 and 13. Lean right. Use legs, wheels, covers, wings or body glide as the seed allows.",
    "running-left": "Same clock and gait facing left, with a clear left lean. Redraw asymmetric carried objects and markings so they stay on their proper side; do not blindly mirror the sheet.",
    "waving": "Face the viewer. Frames 1–6 prepare, 7–12 lift a limb, cover, tip or existing held object, 13–18 make one greeting, 19–24 return. The soldier salutes. Play once.",
    "jumping": "Frames 1–6 compress, 7–12 rise, 13–18 reach the apex and descend, 19–24 land and recover. Flying pets make one upward lift. Clear vertical displacement distinguishes this from running. Play once.",
    "failed": "Frames 1–6 stop, 7–12 lower the head or leading edge, 13–18 hold a small inward pose, 19–24 recover to a steady low stance. No injury, destruction, extinguished life or withering. Play once, then hold.",
    "waiting": "Upright and expectant, gaze turned outward. Frames 1–6 look aside, 7–12 make one small weight shift, 13–24 hold. Loop quietly. Keep the open posture distinct from idle’s relaxed rest and review’s inward attention.",
    "running": "Task in progress, facing front three-quarter without directional travel. Frames 1–6 prepare, 7–12 work, 13–18 inspect, 19–24 reset. Use each seed’s own action: stir with the ram’s herbs, sweep, tend the jar, turn a page, open the fruit or make a measured fork turn. A tiny attached bud opens on the ram’s beat-three check. Loop smoothly.",
    "review": "Stop locomotion and inspect closely. Frames 1–6 lean inward, 7–12 examine an existing object or body detail, 13–18 give one restrained nod, 19–24 hold the result. On the ram, the attached bud unfolds into leaves during frames 13–18: the renewal has a visible moment. No new props, marks or effects. Play once and hold."
  },
  "why": "The family shows care through deliberate work and visible renewal, while each seed keeps its own creature, material and personality. Paul’s approval steps are waived for this run; his later veto remains. No veto is issued here. Originality may veto only in a jury and never ranks taste. Any later veto must quote the exact applicable guards-against charter line and give a concrete reason. The Painter’s function review must inspect the base and sixteen added looks at native size across all nine rows. Record defects as evidence-based flags naming the pet, look, row and frame: for example, a lens rim disappearing, herbs merging with fleece, clipping, or waiting and review sharing an indistinguishable pose. These are review criteria, not claims that sheets have already passed."
}

{
  "seed": "A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.",
  "do_not_resemble": [
    "No franchise look-alike, logo, real-person likeness or copied artwork."
  ]
}

Background requirement: genuine transparency; no labels, guide marks, shadows or background. The family reference is currently missing; DO NOT SUBMIT this job until its input is resolved.
