"""Render extra contract previews from exact final WebP using bundled preview writer."""
from pathlib import Path
from PIL import Image,ImageDraw
import importlib.util,json,hashlib,subprocess
sp=Path('/root/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/create-pet/scripts/render_animation_previews.py')
spec=importlib.util.spec_from_file_location('bundled_preview',sp);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
atlas_path=Path('final/spritesheet.webp');atlas=Image.open(atlas_path).convert('RGBA');out=Path('previews');out.mkdir(exist_ok=True);fr=out/'final-frames'
all_frames=[];durations=[];labeled=[]
for row,(state,ds) in enumerate(m.ROW_DURATIONS.items()):
 d=fr/state;d.mkdir(parents=True,exist_ok=True)
 for col,ms in enumerate(ds):
  im=atlas.crop((192*col,208*row,192*(col+1),208*(row+1)));im.save(d/f'{col:02}.png');all_frames.append(im);durations.append(ms)
  tile=Image.new('RGBA',(192,232),'#eee9de');tile.alpha_composite(im,(0,24));ImageDraw.Draw(tile).text((6,6),f'{state} / {col+1}',fill='#252732');labeled.append(tile)
subprocess.run(['python3',str(sp),'--frames-root',str(fr),'--output-dir',str(out)],check=True,capture_output=True)
m.save_preview(labeled,durations,out/'all-states.gif')
idle=m.load_frames(fr,'idle',6);jump=m.load_frames(fr,'jumping',5)
m.save_preview(idle+jump+idle,m.ROW_DURATIONS['idle']+m.ROW_DURATIONS['jumping']+m.ROW_DURATIONS['idle'],out/'idle-jump-idle.gif')
looks=[atlas.crop((192*(i%8),208*(9+i//8),192*(i%8+1),208*(10+i//8))) for i in range(16)]
m.save_preview(looks,[160]*16,out/'look-loop.gif')
# Four labeled stills plus native ordered transition strip.
sel=[('idle',0),('waving',2),('jumping',2),('review',2)]
still=Image.new('RGBA',(768,232),'#eee9de');draw=ImageDraw.Draw(still)
for i,(state,c) in enumerate(sel):
 im=Image.open(fr/state/f'{c:02}.png');still.alpha_composite(im,(i*192,24));draw.text((i*192+6,6),f'{state} / frame {c+1}',fill='#252732')
still.save(out/'motion-stills.png')
trans=[idle[0]]+jump+[idle[0]];strip=Image.new('RGBA',(192*len(trans),232),'#eee9de');draw=ImageDraw.Draw(strip)
for i,im in enumerate(trans):strip.alpha_composite(im,(i*192,24));draw.text((i*192+5,6),['idle','compress','rise','apex','descend','land','idle'][i],fill='#252732')
strip.save(out/'idle-jump-idle-strip.png')
for name in ['all-states','idle-jump-idle','look-loop']:
 subprocess.run(['ffmpeg','-y','-loglevel','error','-i',str(out/(name+'.gif')),'-vf','format=yuv420p','-movflags','+faststart',str(out/(name+'.mp4'))],check=True)
(out/'manifest.json').write_text(json.dumps({'source':str(atlas_path),'sha256':hashlib.sha256(atlas_path.read_bytes()).hexdigest(),'standard_states':m.ROW_DURATIONS,'look_duration_ms':160,'gif_files':[p.name for p in out.glob('*.gif')],'mp4_files':[p.name for p in out.glob('*.mp4')],'stills':['motion-stills.png','idle-jump-idle-strip.png']},indent=2))
