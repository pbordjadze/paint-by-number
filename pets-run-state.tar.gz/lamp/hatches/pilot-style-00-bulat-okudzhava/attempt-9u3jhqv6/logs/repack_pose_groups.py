"""Repack complete bundled connected-component groups with transparent padding; no cell slicing."""
import sys,json,importlib.util
from pathlib import Path
from PIL import Image
sp=Path('/root/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/create-pet/scripts/extract_strip_frames.py')
spec=importlib.util.spec_from_file_location('bundled_extract',sp);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
src,dst,n=sys.argv[1],sys.argv[2],int(sys.argv[3]);im=Image.open(src).convert('RGBA');groups=m.component_frame_groups(im,n)
if groups is None:raise SystemExit('Bundled component grouping failed')
boxes=[m.component_bounds(g) for g in groups];top=min(b[1] for b in boxes);bottom=max(b[3] for b in boxes);w=max(b[2]-b[0] for b in boxes)+100;h=bottom-top+100
out=Image.new('RGBA',(n*w,h))
for i,(g,b) in enumerate(zip(groups,boxes)):
 tile=m.component_group_image(im,g,padding=0);out.alpha_composite(tile,(i*w+(w-tile.width)//2,50+b[1]-top))
out.save(dst)
Path(dst+'.json').write_text(json.dumps({'source':src,'method':'bundled component_frame_groups and component_group_image; shared transparent padded viewports','groups':n,'source_bounds':boxes,'slot_width':w,'height':h},indent=2))
