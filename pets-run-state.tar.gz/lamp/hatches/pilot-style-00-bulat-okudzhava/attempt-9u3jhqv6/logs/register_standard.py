"""Deterministic row-shared scale/baseline correction after bundled extraction; no redrawing."""
import json,statistics,shutil
from pathlib import Path
from PIL import Image
root=Path('frames'); raw=Path('qa/extracted-original-frames')
if not raw.exists():shutil.copytree(root,raw)
records=[]
for d in raw.iterdir():
 if not d.is_dir():continue
 files=sorted(d.glob('*.png'));ims=[Image.open(p).convert('RGBA') for p in files]
 boxes=[im.getchannel('A').point(lambda a:255 if a>16 else 0).getbbox() for im in ims]
 width=statistics.median(b[2]-b[0] for b in boxes); ground=max(b[3] for b in boxes)
 scale=118/width
 # one identical affine registration for all frames of each row, preserving airborne displacement
 for p,im in zip(files,ims):
  out=im.transform((192,208),Image.Transform.AFFINE,(1/scale,0,96-96/scale,0,1/scale,ground-184/scale),resample=Image.Resampling.BICUBIC)
  out.save(root/d.name/p.name)
 records.append(dict(state=d.name,row_scale=scale,source_ground=ground,target_ground=184,target_median_width=118))
Path('qa/standard-registration.json').write_text(json.dumps(records,indent=2))
p=Path('logs/repairs.json');a=json.loads(p.read_text());a.append('Deterministic standard registration: bundled extraction centered rows near y=201 with 6 px top margins and jump scale smaller than idle. Applied one shared affine scale/translation per complete row to common median silhouette width 118 px and baseline y=184; no individual-frame sizing, preserving source jump displacement.');p.write_text(json.dumps(a,indent=2))
p=Path('logs/decisions.json');a=json.loads(p.read_text());a.append('Tall jump envelope determines common 118 px median bus width; supplemental deterministic row-shared registration restores 16 px safe margins and y=184 baseline after bundled extraction. No art is redrawn.');p.write_text(json.dumps(a,indent=2))
