Create ChatGPT pet row `running` for `bulat-okudzhava`: exactly 6 full-body frames in one horizontal strip on flat pure magenta #FF00FF.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: Fictional little blue trolleybus: warm lit windows, guitar resting on visible herb-green seat, slow kindly temperament. No night street: no scene. Compact blue body, cream roof, gold window light contained inside glass, handmade deep ink edges. A pair of simple drawn expressive eyes on front windshield; attached wiper; two short roof trolley poles. No franchise look-alike, logo, real-person likeness or copied artwork. No family reference. The name is metadata only.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Working loop: focused active-task processing, thinking, typing, scanning, or effortful concentration; not literal foot-running, jogging, sprinting, treadmill motion, raised knees, long steps, pumping arms, or directional travel.

State requirements:
- Show the pet actively working or processing, as if running a task: focused posture, busy hands or paws, purposeful bobbing, thinking motion, tool or prop motion only if already part of the pet identity, or other non-locomotion activity.
- Do not show literal foot-running, jogging, sprinting, treadmill motion, raised knees, long steps, pumping arms, directional travel, speed lines, dust clouds, floor shadows, motion trails, or detached motion effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.
