Create ChatGPT pet row `running-right` for `bulat-okudzhava`: exactly 8 full-body frames in one horizontal strip on flat pure magenta #FF00FF.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: Fictional little blue trolleybus: warm lit windows, guitar resting on visible herb-green seat, slow kindly temperament. No night street: no scene. Compact blue body, cream roof, gold window light contained inside glass, handmade deep ink edges. A pair of simple drawn expressive eyes on front windshield; attached wiper; two short roof trolley poles. No franchise look-alike, logo, real-person likeness or copied artwork. No family reference. The name is metadata only.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Dragging-right loop: show directional movement to the right through body and limb poses only.

State requirements:
- Show directional drag movement to the right through body, limb, and prop movement only.
- The row must unmistakably face and travel right.
- The movement cadence must alternate visibly across the 8 frames instead of repeating one nearly static stride.
- Do not draw speed lines, dust clouds, floor shadows, motion trails, or detached motion effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.
