Create ChatGPT pet row `jumping` for `bulat-okudzhava`: exactly 5 full-body frames in one horizontal strip on flat pure magenta #FF00FF.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: Fictional little blue trolleybus: warm lit windows, guitar resting on visible herb-green seat, slow kindly temperament. No night street: no scene. Compact blue body, cream roof, gold window light contained inside glass, handmade deep ink edges. A pair of simple drawn expressive eyes on front windshield; attached wiper; two short roof trolley poles. No franchise look-alike, logo, real-person likeness or copied artwork. No family reference. The name is metadata only.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Hover jump loop: anticipation, lift, airborne peak, descent, and settle through body height.

State requirements:
- Show the jump through pose and vertical body position only: anticipation, lift, airborne peak, descent, settle.
- Do not draw ground shadows, contact shadows, drop shadows, oval shadows, landing marks, dust, smears, bounce pads, or motion marks under the pet.
- Keep the background outside the pet perfectly flat chroma key with no darker key-colored patches.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.
