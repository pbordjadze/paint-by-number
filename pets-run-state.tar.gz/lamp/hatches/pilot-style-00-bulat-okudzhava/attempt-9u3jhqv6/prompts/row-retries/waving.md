Create ChatGPT pet row `waving` for `bulat-okudzhava`: exactly 4 full-body frames in one horizontal strip on flat pure magenta #FF00FF.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: Fictional little blue trolleybus: warm lit windows, guitar resting on visible herb-green seat, slow kindly temperament. No night street: no scene. Compact blue body, cream roof, gold window light contained inside glass, handmade deep ink edges. A pair of simple drawn expressive eyes on front windshield; attached wiper; two short roof trolley poles. No franchise look-alike, logo, real-person likeness or copied artwork. No family reference. The name is metadata only.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Greeting loop: paw or limb down, raised, tilted, and returning in a friendly attention gesture.

State requirements:
- Show the greeting through paw, hand, wing, or limb pose only.
- Do not draw wave marks, motion arcs, lines, sparkles, symbols, or floating effects around the gesture.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.
