import json,pathlib,shutil,hashlib
from PIL import Image
p=pathlib.Path.cwd();logs=json.load(open('generation-log.json')); out=p/'sources';out.mkdir(exist_ok=True)
for i,e in enumerate(logs):
 dst=out/f"{i+1:02d}-{e['job']}-attempt-{e['attempt']}.png";shutil.copy2(e['source'],dst);e['local_source_copy']=str(dst);e['sha256']=hashlib.sha256(dst.read_bytes()).hexdigest()
 if e['job'] in ['waving','jumping','failed']:
  old=p/f"prompts/rows/{e['job']}-attempt-{e['attempt']}.md"
  if old.exists(): e['prompt']=str(old.relative_to(p))
 e['status']='generated'
json.dump(logs,open('generation-log.json','w'),indent=2)
d=json.load(open('decisions.json'))
d.extend(['Preparation used --force only to initialize this already-created run directory; no outside file was changed.','Preparation automatically selected blue #0000FF as cleanup key; generated sources requested genuine alpha and used the family sheet, canonical base and supplied invisible layout guides.','All 12 generated sources, including discarded repairs, were copied into sources/ with SHA-256 hashes and cache paths in generation-log.json.','Stopped before waiting, work, review, cardinals and look rows because failed row remained rejected after two repairs. No atlas, final despill, continuity or final QA was fabricated.','The final failed-row source corrected the arm count but packed cap edges too closely for reliable connected-pose extraction. Did not substitute assumed equal-slot slicing.','Provisional extracted frames use the bundled default fit; final requested safe framing and baseline were not reached because assembly was blocked.'])
measure={}
for state in ['idle','jumping']:
 rows=sorted((p/f'qa/rows/{state}/frames/{state}').glob('*.png'))
 measure[state]=[Image.open(f).getchannel('A').getbbox() for f in rows]
bottom=[b[3] for b in measure['jumping']];tops=[b[1] for b in measure['idle']]
d.append(f"Motion guidance observation on provisional extraction: idle target breath 1–2 px; silhouette top ranges {min(tops)}–{max(tops)} px, including sprig/cap and blink variation. Jump target lift 10–14 px; extracted frame bottoms {bottom}, range {max(bottom)-min(bottom)} px. Intent in source remains crouch, rise, peak, descent and landing; no repair was spent solely on amplitude. Final motion validation was not reached.")
json.dump(measure,open('qa/provisional-motion-measurements.json','w'),indent=2);json.dump(d,open('decisions.json','w'),indent=2)
jobs=json.load(open('imagegen-jobs.json'))
for j in jobs['jobs']:
 if j['id'] in ['base','idle','running-right','running-left','waving','jumping']:j['status']='passed-local-stage'
 elif j['id']=='failed':j['status']='failed-after-two-repairs'
 else:j['status']='not-started-blocked'
json.dump(jobs,open('imagegen-jobs.json','w'),indent=2)
result=dict(status='failed',reason='Stopped at the two-repair limit for failed row. Bundled inspect_frames.py still rejects frames 01,02,04,05 as empty or sparse after connected-pose extraction. No final atlas was produced; sources and authentic row reports are preserved locally.',image_generations=len(logs),repairs=json.load(open('repairs.json')),contract_overrides=json.load(open('contract_overrides.json')),decisions=d)
json.dump(result,open('result.json','w'),indent=2)
print(json.dumps({'image_generations':len(logs),'reason':result['reason'],'motion':measure},indent=2))
