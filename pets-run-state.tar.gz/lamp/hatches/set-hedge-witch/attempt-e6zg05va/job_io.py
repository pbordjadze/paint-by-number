import json,pathlib,sys,shutil
p=pathlib.Path.cwd(); jobs=json.load(open('imagegen-jobs.json')); job=next(j for j in jobs['jobs'] if j['id']==sys.argv[2]); logs=json.load(open('generation-log.json'))
if sys.argv[1]=='start':
 refs=[str(p/i['path']) for i in job['input_images']]; prompt=(p/job['prompt_file']).read_text(); logs.append({'job':job['id'],'attempt':sum(x['job']==job['id'] for x in logs)+1,'prompt':job['prompt_file'],'references':refs,'status':'started'});json.dump(logs,open('generation-log.json','w'),indent=2);print(json.dumps({'prompt':prompt,'referenced_image_paths':refs,'transparent_background':True}))
elif sys.argv[1]=='save':
 src=pathlib.Path(sys.argv[3]); dst=p/job['output_path'];dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists(): shutil.copy2(dst,dst.with_name(dst.stem+'-previous.png'))
 shutil.copy2(src,dst); logs[-1].update(source=str(src),local=str(dst),status='generated');json.dump(logs,open('generation-log.json','w'),indent=2);print(str(dst))
