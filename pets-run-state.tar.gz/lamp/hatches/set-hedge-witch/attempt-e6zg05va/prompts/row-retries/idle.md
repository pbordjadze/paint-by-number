
Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A low, broad herb-green cap shades a warm cream stem with sincere soot eyes. Moss forms three broad, uneven patches; the unspotted cap has a gently drooping rim. A narrow tarragon sprig rises from its right side. Short stem arms cradle an ochre woven basket at the left hip, its herbs securely contained. Stubby feet, matte paint and slightly wobbled edges keep the silhouette soft and handmade.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Calm low-distraction resting loop: subtle breathing, tiny blink, slight head/body bob, and only quiet persona-preserving motion.

State requirements:
- CRITICAL: idle is the low-distraction baseline state and the first frame is also used as the reduced-motion static pet.
- Use only subtle idle motion: gentle breathing, a tiny blink, a slight head or body bob, a very small material sway, or another quiet motion that fits the pet persona.
- Keep the pet essentially in the same pose, facing direction, silhouette, markings, palette, and prop state across all 6 frames.
- Idle variation must stay calm but still read as animation; do not repeat effectively identical copies across the loop.
- Do not show waving, walking, running, jumping, talking, working, reviewing, emotional reactions, large gestures, item interactions, or new props.
- Feet, base, body, or object anchor should remain planted or nearly planted.
- The first and last frames should be very close visually so the loop feels calm and does not pop.
