
Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A low, broad herb-green cap shades a warm cream stem with sincere soot eyes. Moss forms three broad, uneven patches; the unspotted cap has a gently drooping rim. A narrow tarragon sprig rises from its right side. Short stem arms cradle an ochre woven basket at the left hip, its herbs securely contained. Stubby feet, matte paint and slightly wobbled edges keep the silhouette soft and handmade.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Blocked/failed loop: slumped or deflated reaction with sad or closed eyes.

State requirements:
- Show failure through slumped pose, drooping ears/limbs, closed or sad eyes, and lower body position.
- Tears, small smoke puffs, or tiny stars are allowed only if attached to or overlapping the pet silhouette and kept inside the same frame slot.
- Do not draw red X marks, floating symbols, detached stars, separated smoke clouds, falling tear drops, dust, or other loose effects.
