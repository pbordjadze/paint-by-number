
Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A low, broad herb-green cap shades a warm cream stem with sincere soot eyes. Moss forms three broad, uneven patches; the unspotted cap has a gently drooping rim. A narrow tarragon sprig rises from its right side. Short stem arms cradle an ochre woven basket at the left hip, its herbs securely contained. Stubby feet, matte paint and slightly wobbled edges keep the silhouette soft and handmade.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Hover jump loop: anticipation, lift, airborne peak, descent, and settle through body height.

State requirements:
- Show the jump through pose and vertical body position only: anticipation, lift, airborne peak, descent, settle.
- Do not draw ground shadows, contact shadows, drop shadows, oval shadows, landing marks, dust, smears, bounce pads, or motion marks under the pet.
