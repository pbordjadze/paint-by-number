import json, pathlib, sys, shutil, hashlib
root=pathlib.Path.cwd()
cmd=sys.argv[1]
if cmd=='record':
 job,cache,prompt,refs,output=sys.argv[2:]
 dest=root/output; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(cache,dest)
 rec={'job':job,'cache_path':cache,'local_source':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'prompt_file':prompt,'references':json.loads(refs)}
 with (root/'logs/generations.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
 p=root/'logs/provenance.json'; data=json.loads(p.read_text()); data['image_generations']=len((root/'logs/generations.jsonl').read_text().splitlines());p.write_text(json.dumps(data,ensure_ascii=False,indent=2)); print(json.dumps(rec))
elif cmd=='accept':
 job=sys.argv[2]; p=root/'imagegen-jobs.json'; data=json.loads(p.read_text());
 for j in data['jobs']:
  if j['id']==job:j['status']='complete'
 p.write_text(json.dumps(data,indent=2))
