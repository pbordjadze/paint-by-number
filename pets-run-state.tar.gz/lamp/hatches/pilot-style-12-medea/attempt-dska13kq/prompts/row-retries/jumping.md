Create ChatGPT pet row `jumping` for `pilot-style-12-medea`: exactly 5 full-body frames in one horizontal strip on flat transparent.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.
No franchise look-alike, logo, real-person likeness or copied artwork.
Medea only. Herbs held in mouth, twig attached in back fleece. No other seeds or human figures.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Hover jump loop: anticipation, lift, airborne peak, descent, and settle through body height.

State requirements:
- Show the jump through pose and vertical body position only: anticipation, lift, airborne peak, descent, settle.
- Do not draw ground shadows, contact shadows, drop shadows, oval shadows, landing marks, dust, smears, bounce pads, or motion marks under the pet.
- Keep the background outside the pet fully transparent with no darker key-colored patches.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.


AUTHORITATIVE LOCAL ART CONTRACT: genuine transparent RGBA outside the creature; no colored panel. No labels, guide marks, shadows or floating effects. Never copy guide pixels.

CORRECTED ROW ACTION AND TIMING:
5 frames: compress 0; rise 1; peak 2; descend 3; land/settle 4. Preserve 10–14 native-pixel lift. 140,140,140,140,280 ms, once.
