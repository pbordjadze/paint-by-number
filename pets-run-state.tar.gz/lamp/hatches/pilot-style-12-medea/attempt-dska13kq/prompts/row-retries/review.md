Create ChatGPT pet row `review` for `pilot-style-12-medea`: exactly 6 full-body frames in one horizontal strip on flat transparent.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.
No franchise look-alike, logo, real-person likeness or copied artwork.
Medea only. Herbs held in mouth, twig attached in back fleece. No other seeds or human figures.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Ready-review loop: focused inspection of completed output with lean, blink, narrowed eyes, head tilt, or paw pose.

State requirements:
- Show review through lean, blink, narrowed eyes, head tilt, or paw/hand position.
- Do not add magnifying glasses, papers, code, UI, punctuation, symbols, or other new props unless they already exist in the base pet identity.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.


AUTHORITATIVE LOCAL ART CONTRACT: genuine transparent RGBA outside the creature; no colored panel. No labels, guide marks, shadows or floating effects. Never copy guide pixels.

CORRECTED ROW ACTION AND TIMING:
6 frames: attentive 0; inspect carried herb 1–2; considered hold 3–4; small nod/settle 5. 150 ms each, final 280 ms, once.
