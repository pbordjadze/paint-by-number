Create ChatGPT pet row `running-left` for `pilot-style-12-medea`: exactly 8 full-body frames in one horizontal strip on flat transparent.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.
No franchise look-alike, logo, real-person likeness or copied artwork.
Medea only. Herbs held in mouth, twig attached in back fleece. No other seeds or human figures.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Dragging-left loop: show directional movement to the left through body and limb poses only.

State requirements:
- Show directional drag movement to the left through body, limb, and prop movement only.
- The row must unmistakably face and travel left.
- The movement cadence must alternate visibly across the 8 frames instead of repeating one nearly static stride.
- Do not draw speed lines, dust clouds, floor shadows, motion trails, or detached motion effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.


AUTHORITATIVE LOCAL ART CONTRACT: genuine transparent RGBA outside the creature; no colored panel. No labels, guide marks, shadows or floating effects. Never copy guide pixels.

CORRECTED ROW ACTION AND TIMING:
8 frames, redrawn facing screen-left: first contact 0–1; lift/pass 2–3; opposite contact 4–5; lift/return 6–7. 120 ms each, final 220 ms.
