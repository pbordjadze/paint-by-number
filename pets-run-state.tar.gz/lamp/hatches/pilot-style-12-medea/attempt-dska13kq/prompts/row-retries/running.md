Create ChatGPT pet row `running` for `pilot-style-12-medea`: exactly 6 full-body frames in one horizontal strip on flat transparent.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: A small golden ram whose soft fleece glints like old Colchian gold, carrying a sprig of fresh herbs. Kind eyes; when it's happy, the dry twig on its back sprouts green leaves.
No franchise look-alike, logo, real-person likeness or copied artwork.
Medea only. Herbs held in mouth, twig attached in back fleece. No other seeds or human figures.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Working loop: focused active-task processing, thinking, typing, scanning, or effortful concentration; not literal foot-running, jogging, sprinting, treadmill motion, raised knees, long steps, pumping arms, or directional travel.

State requirements:
- Show the pet actively working or processing, as if running a task: focused posture, busy hands or paws, purposeful bobbing, thinking motion, tool or prop motion only if already part of the pet identity, or other non-locomotion activity.
- Do not show literal foot-running, jogging, sprinting, treadmill motion, raised knees, long steps, pumping arms, directional travel, speed lines, dust clouds, floor shadows, motion trails, or detached motion effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.


AUTHORITATIVE LOCAL ART CONTRACT: genuine transparent RGBA outside the creature; no colored panel. No labels, guide marks, shadows or floating effects. Never copy guide pixels.

CORRECTED ROW ACTION AND TIMING:
6 frames: prepare 0; focused herb-tending gesture 1–2; check 3–4; reset 5. Planted hooves; no locomotion. 120 ms each, final 220 ms.
