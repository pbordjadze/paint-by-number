import json
from pathlib import Path
R=Path.cwd(); taste=(R/'logs/taste.txt').read_text()
mechanics='Medea stands on four planted hooves with her ochre fleece torso anchored in the canonical three-quarter front stance. Only the neck and head turn and pitch; horns and ears follow the skull, natural eyes and cream muzzle lead the gaze. Herbs stay gripped in her mouth and the back twig stays attached on its original flank. Keep both face and sincere original eyes readable, including upward and downward poses. No whole-body turntable.'
(R/'qa/look-mechanics.md').write_text(mechanics)
for p in [R/'prompts/look-cardinals.md',R/'prompts/rows/look-row-9.md',R/'prompts/rows/look-row-10.md']:
 t=p.read_text().replace('flat pure magenta #FF00FF background','genuinely transparent background')
 t+='\n\nFULL BINDING TASTE AND PET NOTES:\n'+taste+'\n\nLOOK MECHANICS:\n'+mechanics+'\n\nProduction: generate a wide horizontal strip with generous transparent outer margins, distinct non-touching complete poses. No labels in the art. All poses same scale and ground line. The layout guide is invisible spacing guidance, not art. Final cells are 192 x 208; this strip is extracted by connected poses and registered into that geometry. Keep the mouth herb and attached twig intact. Use identical palette and material in every pose.\n'
 p.write_text(t)
