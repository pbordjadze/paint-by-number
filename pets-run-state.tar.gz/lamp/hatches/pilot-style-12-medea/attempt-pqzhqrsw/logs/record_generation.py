import json,sys,shutil,hashlib
from pathlib import Path
job,cache,prompt,*refs=sys.argv[1:];R=Path.cwd();out=R/'sources'/f'{job}.png';shutil.copy2(cache,out)
rec={'job':job,'cache_path':cache,'local_source':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'prompt_file':prompt,'references':refs}
with (R/'logs/generations.jsonl').open('a') as f:f.write(json.dumps(rec)+'\n')
p=R/'logs/provenance.json';d=json.loads(p.read_text());d['image_generations']=len((R/'logs/generations.jsonl').read_text().splitlines());p.write_text(json.dumps(d,indent=2))
shutil.copy2(out,R/'decoded'/f"{job.split('-repair-')[0]}.png")
