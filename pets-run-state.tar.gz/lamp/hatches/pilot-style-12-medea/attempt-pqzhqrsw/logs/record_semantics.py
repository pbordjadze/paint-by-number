import json
from pathlib import Path
labels=['000','022.5','045','067.5','090','112.5','135','157.5','180','202.5','225','247.5','270','292.5','315','337.5']
expected=['up','up-right','up-right','up-right','right','down-right','down-right','down-right','down','down-left','down-left','down-left','left','up-left','up-left','up-left']
evidence=[
'Chin lifts, cream muzzle points above the eye line and pupils sit high; body and hooves remain upright.',
'Head yaws screen-right with nose right of the eye; raised chin and upper-directed pupil provide the upward axis.',
'Muzzle projects right and tilts upward; visible eye looks above its horizontal center. Similar to adjacent poses but both axes read.',
'Rightward muzzle projects beyond eye and neck while chin remains raised and pupil directed upward; subtle step from 045.',
'Level cream muzzle and nose project clearly screen-right; visible eye follows horizontally. Hooves stay planted.',
'Nose projects screen-right, but muzzle pitches downward and visible eye drops from the level cardinal toward the herb.',
'Head remains right of center while chin lowers toward fleece; lowered eyelids and muzzle establish down-right.',
'Cream muzzle points low and screen-right, with eye looking down; head stays attached between the horns and fleece.',
'Frontal head bows over the chest, nose is centered low between the front hooves, and both pupils look down.',
'Head turns screen-left and bows, nose below and left of the visible eye; carried herb follows the lowered mouth.',
'Lowered muzzle points left of eye center, pupil looks down-left; near-duplicate pitch of 202.5 but same quadrant.',
'Muzzle projects screen-left with a modest downward slope; eye tracks left and lower than the level cardinal.',
'Level muzzle projects distinctly screen-left; visible pupil follows left. Torso and attached twig stay oriented as before.',
'Head pitches up and left, raised nose left of the eye and upward-looking pupil establish both axes.',
'Cream muzzle extends upper-left and chin is lifted; eye follows that upward-left aim, similar to neighbor.',
'Raised muzzle and pupil point upper-left; near the preceding pose, retaining both axes before returning to frontal up.'
]
records=[{'direction':l,'expected':e,'observed':e,'verdict':'warning' if l in ['022.5','045','067.5','202.5','225','315','337.5'] else 'pass','evidence':v} for l,e,v in zip(labels,expected,evidence)]
Path('qa/direction-semantics.json').write_text(json.dumps({'directions':records,'continuity_review':'Reviewed native-size labeled sheet and ordered look frames. Subtle angular steps cluster in the upper diagonal families. Flagged 157.5-to-180 change is a rightward profile resolving into frontal bowed head; 270-to-292.5 raises the chin; 337.5-to-000 returns a partial profile to frontal upward gaze. Hooves retain ground contact and back twig stays on screen-right. No wrong cardinal, missing quadrant, detached prop or alpha hole is visible. The metrics are review warnings, not waived gate failures.'},indent=2))
