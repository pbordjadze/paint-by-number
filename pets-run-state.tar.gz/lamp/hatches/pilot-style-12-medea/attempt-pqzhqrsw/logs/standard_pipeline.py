import json,subprocess
from pathlib import Path
from PIL import Image
R=Path.cwd(); S=Path('/root/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/create-pet/scripts')
def run(script,*args):
 p=subprocess.run(['python3',str(S/script),*map(str,args)],capture_output=True,text=True)
 (R/'logs'/f'{script}.log').open('a').write(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError(p.stdout+p.stderr)
 return p.stdout
states=['idle','running-right','running-left','waving','jumping','failed','waiting','running','review']
for state in states:
 run('extract_strip_frames.py','--decoded-dir',R/'decoded','--output-dir',R/'qa/rows'/state/'frames','--states',state,'--method','auto')
 run('inspect_frames.py','--frames-root',R/'qa/rows'/state/'frames','--json-out',R/'qa/rows'/state/'review.json','--states',state,'--require-components')
run('extract_strip_frames.py','--decoded-dir',R/'decoded','--output-dir',R/'frames-raw','--method','auto')
# Deterministic framing of bundled-extracted pixels only. One scale for all standard frames, one baseline offset per row.
transforms={}
for state in states:
 files=sorted((R/'frames-raw'/state).glob('*.png')); frames=[Image.open(f).convert('RGBA') for f in files]
 scaled=[im.resize((157,171),Image.Resampling.LANCZOS) for im in frames]
 bottom=max(im.getbbox()[3] for im in scaled); ty=184-bottom
 out=R/'frames'/state;out.mkdir(parents=True,exist_ok=True)
 for f,im in zip(files,scaled):
  canvas=Image.new('RGBA',(192,208));canvas.alpha_composite(im,(18,ty));canvas.save(out/f.name)
 transforms[state]={'scale':[157/192,171/208],'translation':[18,ty],'bottoms':[im.getbbox()[3]+ty for im in scaled]}
(R/'logs/standard-registration.json').write_text(json.dumps(transforms,indent=2))
print(run('inspect_frames.py','--frames-root',R/'frames','--json-out',R/'qa/review.json','--require-components'))
print(run('compose_atlas.py','--frames-root',R/'frames','--output',R/'final/standard.png'))
print(run('make_contact_sheet.py',R/'final/standard.png','--output',R/'previews/standard-contact.png'))
print(run('render_animation_previews.py','--frames-root',R/'frames','--output-dir',R/'previews/standard'))
