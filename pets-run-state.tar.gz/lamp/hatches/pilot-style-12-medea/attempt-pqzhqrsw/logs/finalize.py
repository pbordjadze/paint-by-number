import json,hashlib
from pathlib import Path
from PIL import Image
R=Path.cwd()
Image.open('previews/contact-sheet.png').convert('RGB').save('previews/contact-sheet.webp','WEBP',quality=72,method=6)
obs={}
for state in ['idle','jumping']:
 bounds=[]
 for p in sorted((R/'final/frames'/state).glob('*.png')):
  a=Image.open(p).getchannel('A');bounds.append(a.point(lambda v:255 if v>16 else 0).getbbox())
 obs[state]=bounds
(R/'logs/motion-observations.json').write_text(json.dumps(obs,indent=2))
p=R/'logs/provenance.json';d=json.loads(p.read_text())
d['decisions'] += [
'Final jump target 10–14 pixels; observed bundled-quality lift 26 pixels and landing delta 1 pixel using alpha>16. The frame sequence preserves compression, ascent, apex, descent and settled return; no amplitude-only repair was made.',
'Idle target 1–2-pixel breath plus slow blink: full silhouette top varies subtly while the baseline stays fixed; visible eyelid closure and reopening provide the main life cue. Body-bound changes are not a separate acceptance threshold.',
'Framing uses y=184 including antialias fringe; bundled alpha>16 baseline is y=181 for idle and y=182 for landed jump. This preserves shared visual ground contact without treating guidance as a hard coordinate gate.',
'Standard rows were re-extracted and inspected individually in contract order, then jointly assembled and inspected; accepted base and nine source rows were reused, not regenerated.',
'Four new built-in imagegen calls: cardinal original, cardinal repair 1, row 9, row 10. Historical 16 calls are logged separately; no whole-pet or jury redo occurred.',
'Three isolated read-only reviewers classified the randomized blind sheet; all 28 axis classifications per reviewer agreed and the bundled majority validator passed. One reviewer also passed final contact, look and motion-still review.',
'Continuity and semantic warnings retain subtle neighboring diagonal poses and profile-to-frontal changes. All principal quadrants and cardinals passed blind review; no alpha holes, clipping or visible detached props were found.',
'One despill pass was applied to the assembled candidate. Encoding revisions reuse its cleaned pixels without any additional despill.',
'All final previews were rendered from the exact validated WebP: nine state GIFs, all-state GIF/MP4, idle-jump-idle GIF/MP4, look-loop GIF/MP4, contact/direction sheets and six labeled stills.',
'All artifacts remain local; no Pets MCP, Library or service lifecycle calls were made. Read-only reviewers were the only delegated work.'
]
d['status']='complete';d['reason']='Local v2 candidate completed; exact final WebP passes bundled atlas, frame, quality, continuity and blind-direction checks.'
p.write_text(json.dumps(d,indent=2))
(R/'qa/independent-final-review.json').write_text(json.dumps({'reviewer':'/root/blind_review_a','verdict':'pass','blocking_defects':[], 'evidence':['Golden fleece, curled horns, cream muzzle, dark hooves, mouth herbs, and rear twig remain recognizable across states and directions.','Waving raises a hoof; jumping lifts the body and feet; failed collapses into a crouch; side-running changes leg positions; waiting blinks; running dips the head; review tilts it.','Direction sweep clearly separates left/right and up/down. The 157.5-to-180 and 337.5-to-000 boundaries change head orientation coherently without losing identity.','No visible clipping, detached herbs, missing twig, or malformed limbs in occupied cells.'],'nonblocking':['Several neighboring diagonal directions look very similar; idle/waiting/review have comparatively subtle differences at native size.']},indent=2))
p=R/'imagegen-jobs.json';j=json.loads(p.read_text());next(x for x in j['jobs'] if x['id']=='look-row-10')['status']='complete';p.write_text(json.dumps(j,indent=2))
meta={'pet':'medea','key':'pilot-style-12-medea','sprite_version_number':2,'local_only':True,'atlas':'final/spritesheet.webp','sha256':hashlib.sha256((R/'final/spritesheet.webp').read_bytes()).hexdigest(),'contact':'previews/contact-sheet.webp','qa_reports':['qa/chroma-despill-extended.json','qa/review.json','qa/direction-semantics.json','qa/look-continuity.json','qa/pet-quality.json','final/validation-extended.json','qa/blind-validation.json'],'image_generations':d['image_generations'],'historical_image_generations':16,'contract_overrides':d['contract_overrides'],'decisions':d['decisions'],'repairs':d['repairs']}
(R/'final/metadata.json').write_text(json.dumps(meta,indent=2))
files=['final/spritesheet.webp','previews/contact-sheet.webp','final/metadata.json'];sizes={f:(R/f).stat().st_size for f in files}
(R/'logs/package-size.json').write_text(json.dumps({'files':sizes,'combined_bytes':sum(sizes.values()),'limit_bytes':2000000},indent=2));assert sum(sizes.values())<2000000
for f in meta['qa_reports']:assert (R/f).is_file()
for f in ['final/validation-extended.json','qa/review.json','qa/pet-quality.json','qa/blind-validation.json']:assert json.loads((R/f).read_text())['ok']
assert meta['sha256']==json.loads((R/'qa/pet-quality.json').read_text())['sha256']
print(json.dumps({'sizes':sizes,'combined_bytes':sum(sizes.values()),'motion_bounds':obs},indent=2))
result={k:d[k] for k in ['status','reason','image_generations','repairs','contract_overrides','decisions']};(R/'logs/final-result.json').write_text(json.dumps(result,indent=2))
