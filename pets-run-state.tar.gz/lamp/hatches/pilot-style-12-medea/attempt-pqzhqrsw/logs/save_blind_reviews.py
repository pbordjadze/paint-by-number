import json
from pathlib import Path
votes=[('screen-right','screen-left'),('screen-right','screen-left'),('screen-left','screen-right'),('screen-right','screen-left'),('screen-right','screen-left'),('screen-right','screen-left'),('screen-right','screen-left'),('down','up'),('down','up'),('down','up'),('down','up'),('up','down'),('up','down'),('down','up')]
reasons={
'a':[
"A's muzzle projects right with its visible eye looking right; B's muzzle and eye point left.",
"A has its nose on the right edge of the face; B has its nose on the left edge.",
"A's projecting muzzle and gaze face left; B's projecting muzzle and gaze face right.",
"A's nose extends right beyond its visible eye; B's nose extends left beyond its visible eye.",
"A's lowered muzzle turns toward the right; B's lowered muzzle projects toward the left.",
"Despite downward pitch, A's nose lies to the right of its eye, while B's nose lies to the left.",
"Both heads are lowered; A's muzzle angles right and B's muzzle angles left.",
"A bows its head with nose below the eyes and forehead prominent; B raises its muzzle above the eyes.",
"A's eyes and nose angle downward beneath its forehead; B lifts its nose with its eye looking upward.",
"A has a lowered muzzle and downward gaze; B has an elevated muzzle and upward gaze.",
"A's muzzle falls below its eye and its forehead tips forward; B's muzzle tilts upward and its eye looks up.",
"A's left-facing muzzle is lifted near eye height with upward gaze; B's nose hangs below its eye beneath a bowed forehead.",
"A raises its left-facing nose and looks upward; B lowers its nose and looks toward the ground.",
"A's nose points down beneath its eye; B's nose rises toward the upper left with an upward-directed eye."],
'b':[
"A's muzzle projects right of its visible eye; B's muzzle and mouth sprig project left.",
"A has its nose on the right edge of the face; B has its nose on the left edge.",
"A's projecting muzzle points left, away from its horn; B's projecting muzzle points right.",
"A's nose and eye face right; B's nose and eye face left, with its mouth sprig extending left.",
"A's lowered muzzle lies right of the visible eye and horn; B's lowered muzzle projects toward the left.",
"A's bowed face angles down and right; B's bowed face angles down and left, with its nose at the leftmost facial edge.",
"A's nose and muzzle descend toward the right side of its face; B's descend toward the left side.",
"A bows its head, placing its eyes and muzzle low beneath the forehead; B raises its muzzle above the eyes and exposes the underside of its chin.",
"A's muzzle drops toward its chest and its visible eye looks downward; B tilts its nose upward with an elevated gaze.",
"A's head slopes forward and down toward the mouth sprig; B lifts its muzzle and directs its eye upward.",
"A carries its muzzle low beneath the eye; B's elongated muzzle angles upward and the visible eye follows that direction.",
"A raises its left-pointing nose and looks upward; B bows its face toward the chest with its muzzle below the eye.",
"A's muzzle is elevated and its visible eye points upward; B's forehead slopes down to a low muzzle and downward gaze.",
"A's lowered head places its nose and mouth sprig beneath its eye; B lifts its muzzle toward the upper left with an upward gaze."],
'c':[
"A's projecting muzzle and eye face right; B's projecting muzzle and eye face left.",
"A's nose extends right beyond its visible eye; B's nose extends left beyond its visible eye.",
"A shows a left-facing muzzle with the horn behind it on the right; B shows the mirrored right-facing profile.",
"A's cream muzzle protrudes toward the right; B's cream muzzle protrudes toward the left.",
"A's lowered muzzle points right of its visible eye; B's lowered muzzle points left of its visible eye.",
"A's nose is directed down and right beneath its eye; B's nose is directed down and left beneath its eye.",
"A's lowered face turns right, with the nose right of the eye; B's lowered face turns left, with the nose left of the eye.",
"A exposes the top of its bowed head and points its muzzle downward; B lifts its muzzle above its eyes with its chin exposed.",
"A's eye and muzzle angle toward the ground; B raises its nose and directs its eye upward.",
"A's muzzle drops below its visible eye; B's projecting nose is lifted and its gaze points upward.",
"A's nose slopes below the eye toward the hanging leaves; B's nose projects upward with the head tilted back.",
"A holds its muzzle raised and looks upward; B bows its head with its muzzle and gaze aimed toward the ground.",
"A lifts its left-facing muzzle above its eye line; B lowers its left-facing muzzle beneath its eye.",
"A's muzzle droops beneath its eye with a bowed head; B raises its muzzle and turns its eye upward."]}
for name,rr in reasons.items():
 pairs=[{'pair':f'{"horizontal" if i<7 else "vertical"}-{i%7+1}','A':v[0],'B':v[1],'reason':reason} for i,(v,reason) in enumerate(zip(votes,rr))]
 Path(f'qa/blind-review-{name}.json').write_text(json.dumps({'reviewer':f'/root/blind_review_{name}','pairs':pairs},indent=2))
