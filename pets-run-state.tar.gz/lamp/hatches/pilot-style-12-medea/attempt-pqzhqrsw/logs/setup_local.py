import json,shutil,subprocess,hashlib
from pathlib import Path
R=Path.cwd(); P=R.parent/'attempt-dska13kq'; S=Path('/root/.codex/plugins/cache/openai-curated-remote/work-pets/0.1.6/skills/create-pet/scripts')
request=json.loads((P/'logs/request.json').read_text()); (R/'logs/request.json').write_text(json.dumps(request,indent=2))
old=json.loads((P/'logs/provenance.json').read_text()); overrides=old['contract_overrides']
for o in overrides:
 if o['source']=='style.rows.jumping': o['replacement']=o['replacement'].replace('Preserve 10–14 native-pixel lift.','Use 10–14 native pixels as drawing guidance only; retain natural visible lift and landing without a separate amplitude gate.')
prov={'contract_overrides':overrides,'decisions':old['decisions'][:11]+['Continuation reuses prior canonical base and nine selected animation strips, preserving prior attempt read-only. Prior 16 generations are historical and excluded from this attempt’s new-call count.','Prior jump amplitude-only rejection is superseded: 31-pixel extracted lift versus 10–14 target retains a clear compress-rise-peak-descend-land action; it is not grounds for regeneration.','Normalize all extracted standard frames with one shared 0.82 scale and one translation per row to fit the requested safe framing and y=184 baseline, preserving source jump displacement.'], 'image_generations':0,'historical_image_generations':16,'repairs':[], 'status':'in_progress'}
(R/'logs/provenance.json').write_text(json.dumps(prov,indent=2))
pr=json.loads((P/'pet_request.json').read_text())
subprocess.run(['python3',str(S/'prepare_pet_run.py'),'--pet-name','Medea','--pet-id','pilot-style-12-medea','--description',pr['description'],'--pet-notes',pr['pet_notes'],'--style-preset','painterly','--style-notes',pr['style_notes'],'--output-dir',str(R),'--force'],check=True)
for d in ['sources','decoded','references','logs/prior']:(R/d).mkdir(parents=True,exist_ok=True)
shutil.copytree(P/'prompts',R/'logs/prior/prompts',dirs_exist_ok=True)
for f in ['generations.jsonl','provenance.json','remaps.json']:shutil.copy2(P/'logs'/f,R/'logs/prior'/f)
records=[]
for line in (P/'logs/generations.jsonl').read_text().splitlines():
 rec=json.loads(line); src=Path(rec['local_source'])
 if src.parent.name!='decoded':continue
 cache=Path(rec['cache_path']); dest=R/'decoded'/src.name
 used=cache if cache.exists() else src
 shutil.copy2(used,dest)
 assert hashlib.sha256(dest.read_bytes()).hexdigest()==rec['sha256']
 records.append({'job':rec['job'],'cache_path':str(cache),'copied_from':str(used),'local_source':str(dest),'sha256':rec['sha256'],'prior_prompt':str(R/'logs/prior'/rec['prompt_file']),'reused':True})
(R/'logs/reused-sources.json').write_text(json.dumps(records,indent=2))
shutil.copy2(R/'decoded/base.png',R/'references/canonical-base.png')
(R/'logs/generations.jsonl').touch()
(R/'logs/taste.txt').write_text(pr['style_notes']+'\nPET NOTES: '+pr['pet_notes'])
