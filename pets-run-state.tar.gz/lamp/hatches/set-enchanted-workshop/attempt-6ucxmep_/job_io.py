import json,sys,pathlib,shutil
root=pathlib.Path(__file__).parent; mode=sys.argv[1]; name=sys.argv[2]; manifest=root/'imagegen-jobs.json'; data=json.loads(manifest.read_text()); job=next(j for j in data['jobs'] if j['id']==name)
if mode=='read':
 print(json.dumps(dict(prompt=(root/job['prompt_file']).read_text(),references=[str(root/i['path']) for i in job['input_images']])))
elif mode=='save':
 src=sys.argv[3]; out=root/job['output_path']; out.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,out); logpath=root/'generation-log.json'; log=json.loads(logpath.read_text()); attempt=1+sum(x['job']==name for x in log); saved=root/'sources'/f'{name}-{attempt}.png'; saved.parent.mkdir(exist_ok=True); shutil.copy2(src,saved); log.append(dict(job=name,attempt=attempt,source=src,local=str(out),preserved_source=str(saved),prompt=job['prompt_file'],references=job['input_images'])); logpath.write_text(json.dumps(log,indent=2)); print(str(out))
elif mode=='pass':
 job['status']='complete'; manifest.write_text(json.dumps(data,indent=2))
