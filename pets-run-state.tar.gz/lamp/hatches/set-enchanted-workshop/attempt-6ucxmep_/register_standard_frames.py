"""Deterministic padding/registration correction of bundled extracted pixels; no artwork drawing."""
from PIL import Image
from pathlib import Path
import shutil,json
root=Path('frames'); archive=Path('qa/extracted-before-registration')
if not archive.exists(): shutil.copytree(root,archive)
records=[]
for state in archive.iterdir():
 if not state.is_dir():continue
 scale=168/198 if state.name=='jumping' else .75
 for source in state.glob('*.png'):
  im=Image.open(source).convert('RGBA'); size=(round(im.width*scale),round(im.height*scale)); resized=im.resize(size,Image.Resampling.LANCZOS); out=Image.new('RGBA',(192,208)); offset=(round(96-96*scale),round(184-203*scale));out.alpha_composite(resized,offset);out.save(root/state.name/source.name)
 records.append(dict(state=state.name,shared_scale=scale,anchor='x=96, ground=184; preserve row-relative vertical displacements'))
Path('qa/standard-registration.json').write_text(json.dumps(records,indent=2))
f=Path('decisions.json');d=json.loads(f.read_text());d.append('After bundled component extraction, apply one shared transform per row: standard rows 0.75 scale, jumping 168/198 scale, centered x=96 and ground y=184. This removes oversized cell filling and matches crown widths while preserving every generated jump displacement; no per-frame resizing.');f.write_text(json.dumps(d,indent=2))
