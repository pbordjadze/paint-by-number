Create ChatGPT pet row `running-left` for `dab`: exactly 8 full-body frames in one horizontal strip on flat pure user-selected #FF00FF.

Use the attached canonical base for identity and the layout guide only for spacing. Same pet in every frame: Dab is a small, broad paintbrush with tiny legs, a determined face on its wooden handle, and a paint jar held close in one short hand. Its cream bristles form a slightly uneven crown above a dull blue collar; ochre wood and rust shoes give it a warm, practical shape. Sincere soot eyes and firm brows show a worker who cares about getting a small job right.

Dab chooses painting jobs for itself. Its signature habit is to lift its jar, bend its bristles toward the opening, and carefully wipe them against the inside rim. The jar stays upright and every trace of paint remains on the brush or inside its belonging. A planted stance and visible bristle contact make the work clear without a painted surface or extra tools.

Its resolve has room for feeling: a proud straightening after a neat wipe, an eager greeting, an expectant lean, and a disappointed slump when a job goes poorly. Failure brings a quiet recovery rather than panic. Waiting looks outward; work makes repeated contact with the jar; review lifts the jar for a still, deliberate inspection.

Keep its tasks small and specific to painting. Preserve its legs, face, jar, and independent purpose through every pose. Use broad matte color, restrained fixed marks, and gently uneven edges, with no scenery or detached magic.
A squat ochre handle carries a determined face beneath a dull blue collar and cream bristle crown. Two tiny rust shoes spread for balance. Short soot arms keep the rounded herb green paint jar secure, its cream inner rim clearly open. Use broad matte fills, sincere eyes, and a few fixed grain marks. Keep the face large and the jar separate from the legs.
Jar stays in anatomical left hand. Do not resemble: No franchise look-alike, logo, real-person likeness or copied artwork. Tools that work on their own doing chores are Fantasia's enchanted brooms and Beauty and the Beast's enchanted household objects. Keep the brush and paint jar, but give it painting-only jobs like rinsing and sorting brushes, and its own face rather than a fetch-water gag.
Readability: waiting outward with low jar; work visible bristle contact with inner rim; review raised-jar inspection away from bristles. Adjacent looks turn face/crown/shoulders incrementally.. Preserve silhouette, face, palette, material, proportions, markings, and props.

Keep apparent pet scale and baseline stable within the row unless the state itself intentionally changes vertical position, such as `jumping`.

Action: Dragging-left loop: show directional movement to the left through body and limb poses only.

State requirements:
- Show directional drag movement to the left through body, limb, and prop movement only.
- The row must unmistakably face and travel left.
- The movement cadence must alternate visibly across the 8 frames instead of repeating one nearly static stride.
- Do not draw speed lines, dust clouds, floor shadows, motion trails, or detached motion effects.

One centered complete pose per invisible slot. No text, boxes, guide marks, scenery, shadows, glows, motion blur, speed lines, dust, detached effects, stray pixels, or #FF00FF colors in the pet.
